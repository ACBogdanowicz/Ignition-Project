def setMaterialDefCP(matDefName, cpName, cpValue):
    #This function takes the name of a Material Definition, a custom property name and a value to set it.
    #In this implementation, we are requiring the custom property to either already exist for the Material Definition or be inherited from the Material Class for this Material Definition
    #but this is not a requirement of the object model
    print 'Calling setMaterialDefCP for %s to set %s Custom Property to %s' % (matDefName, cpName, cpValue)
     
    matDef = system.mes.loadMESObject(matDefName, 'MaterialDef')
    bFound = True
     
    #This will only return the custom properties that have been added to the material definition.
    cps = matDef.getCustomProperties()
    print cps
    for cp in cps.keySet():
        if cp == cpName:    #Find the one that you want to override
            print "Custom property - %s already exists. Setting it to %s" %(cpName, cpValue)
            matDef.setPropertyValue(cpName, cpValue)
            bFound = True
             
            system.mes.saveMESObject(matDef)    #Don't forget to save
     
    #This will return custom properties that have been added to the material definition and any parents.
     
    if bFound == False:
        #Get all of the custom properties
        cpList = matDef.getAllCustomProperties()
        for cp in cpList:
            #Find the one that you want to override
            if cp.getName() == cpName:
                print "Creating Custom Property - %s for this material def and setting its value to %s" % (cpName, cpValue)
                #Make a clone of it
                newCP = cp.clone()
                #Add it to the material definition with the overrideInherited flag set to True
                matDef.addCustomProperty(newCP, True)
                matDef.setPropertyValue(cpName, cpValue)
         
        #Now the material definition has it's own custom property  
        print matDef.getAllCustomProperties()
        system.mes.saveMESObject(matDef)    #Don't forget to save