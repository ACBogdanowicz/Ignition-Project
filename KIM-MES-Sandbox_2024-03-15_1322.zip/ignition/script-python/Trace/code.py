import system

def do(lotnumber):
	ml = system.mes.loadMaterialLot(lotnumber,-1,True)
	print ml.getPropertyValue('UUID')
	
	dataset = system.mes.getLotTraceByLotUUID(ml.getPropertyValue('UUID'),'')
	print dataset
	prevuuids = dataset.getColumnAsList(19)
	print prevuuids
	
	print '0,prev ', dataset.getValueAt(0,'PrevLotUUID')
	print '0,next ', dataset.getValueAt(0,'NextLotUUID')
	print '1,prev', dataset.getValueAt(1,'PrevLotUUID')
	print '1,next ', dataset.getValueAt(1,'NextLotUUID')
	
	segUUID = dataset.getValueAt(1,'SegmentUUID')
	seg = system.mes.getMESObjectLink(segUUID).getMESObject()
	print seg.name
	cp = seg.getAllCustomProperties()
	print cp
	
	
	while 1:	
		dataset = system.mes.getLotTraceByLotUUID(dataset.getValueAt(1,'NextLotUUID'),'')
		print dataset
		print dataset.getColumnNames()
		lastrow = dataset.getRowCount()
		print lastrow
		for i in range(1,lastrow):
			print i
			rowuuid = dataset.getValueAt(i,'LotUUID')
			print rowuuid 
			print dataset.getValueAt(i,'SegmentName')
			rl = system.mes.getMESObjectLink(dataset.getValueAt(i,'LotUUID')).getMESObject()
			lotuse = dataset.getValueAt(i,'LotUse')
			print rl.name
			print rl.getLotSequence()
			if lotuse == 'In':
				print dataset.getValueAt('SegmentUUID')
			
			
		print dataset.getValueAt(lastrow,'NextLotUUID')
		if dataset.getValueAt(1,'NextLotUUID') == None:
			print 'none'
		print (dataset)
		#print dataset
		#print '1,next ', dataset.getValueAt(1,'NextLotUUID')
		#segUUID = dataset.getValueAt(1,'SegmentUUID')
		#seg = system.mes.getMESObjectLink(segUUID).getMESObject()
		#print seg.name
		#cp = seg.getAllCustomProperties()
		#print cp