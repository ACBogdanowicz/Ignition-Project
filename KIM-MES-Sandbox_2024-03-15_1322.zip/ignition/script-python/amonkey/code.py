lotuuid = system.tag.readBlocking(['[MES_Tags]Sandbox/general_utility/lookup_transfer_lot'])[0].value
print (lotuuid)
lobj = system.mes.loadMESObject(lotuuid)
print lobj.name
responseuuid = lobj.getPropertyValue('ResponseSegmentUUID')
response = system.mes.loadMESObject(responseuuid)

hold_on_delay = 5
hold_off_delay = 5
hold_delay = 400
release_on_delay = 5
release_off_delay = 6
release_delay = 5

releaseend = system.date.addMinutes(system.date.now(), -release_off_delay)
releasestart = system.date.addMinutes(releaseend, -release_on_delay - release_delay)

holdend = system.date.addMinutes(releasestart, -hold_delay + -hold_off_delay)
holdstart = system.date.addMinutes(response.getEndDateTime(), hold_on_delay)
holdstart = system.date.addMinutes(holdend, -hold_on_delay + -hold_delay)

print response.getEndDateTime(), 'prevend'
print holdstart, 'holdstart'
print holdend, 'holdend'

print releasestart, 'releasestart'
print releaseend, 'releaseend'
print system.date.now(), 'saw or scalp'

if lobj.getLocationLink().name == 'Stress Relief Staging':
	# this lot should be placed into Ingot Inventory after being send to Stress Relief QMR
	# Operation Hold via MES Line
	pass
	# Operation Release via MES Line