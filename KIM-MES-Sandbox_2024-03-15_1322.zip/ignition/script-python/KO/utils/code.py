import StringIO
def lotCheckShow(lotno,spaces=0):
	trace = 1
	ml = system.mes.loadMaterialLot(lotno,-1,1)
	if trace:
		print ' ' * spaces + 'Lot: ' + ml.name
	spaces = spaces + 5
	if trace:
		print ' ' * spaces + str(ml.getProperty('LotSequence').value)
		print ' ' * spaces + str(ml.getLotAvailabilityStatus())
		print ' ' * spaces + ml.getProperty('LotStatus').value
		print ' ' * spaces + ml.getProperty('MaterialRefType').value
		print ' ' * spaces + ml.getMaterialDefLink().getMESObject().name
		print ' ' * spaces + ml.getLocationLink().getMESObject().name
	custlist = ml.getAllCustomProperties()
	if 'Length' in custlist:
		if trace:
			print 'Length is present 1'
	if trace:
		print custlist
	for c in custlist:
		if c.name == 'Length':
			if trace:
				print 'Length is present 2'
		if trace:
			print c.value
	if str(ml.getLotAvailabilityStatus()) == 'AVAILABLE':
		return 1
	else:
		return 0
		
def lotCheckAsString(lotno,spaces = 0):
	rstr.write('%s\n' % ( ' ' * spaces + 'Lot: ' + ml.name ))
	spaces = spaces + 5

	rstr.write('%s\n' % ( ' ' * spaces + str(ml.getProperty('LotSequence').value)))
	rstr.write('%s\n' % ( ' ' * spaces + str(ml.getLotAvailabilityStatus())))
	rstr.write('%s\n' % ( ' ' * spaces + ml.getProperty('LotStatus').value))
	rstr.write('%s\n' % ( ' ' * spaces + ml.getProperty('MaterialRefType').value))
	rstr.write('%s\n' % ( ' ' * spaces + ml.getMaterialDefLink().getMESObject().name))
	rstr.write('%s\n' % ( ' ' * spaces + ml.getLocationLink().getMESObject().name))
	return rstr

def lotCheckLog(lotno,logname,spaces=0):
	#system.util.getLogger(logname).info("lotCheckLog %s" % lotno)
	trace = 0
	ml = None
	try:
		ml = system.mes.loadMaterialLot(lotno,-1,1)
		lseq = ml.getLotSequence()
		system.util.getLogger(logname).info("lotCheckLog %s PASS %s" % (lotno,lseq))
	except:
		system.util.getLogger(logname).info("lotCheckLog %s FAIL" % lotno)
		return 0
	if trace:
		system.util.getLogger(logname).info(' ' * spaces + 'Lot: ' + ml.name)
	spaces = spaces + 5
	if trace:
		system.util.getLogger(logname).info(' ' * spaces + str(ml.getProperty('LotSequence').value))
		system.util.getLogger(logname).info(' ' * spaces + str(ml.getLotAvailabilityStatus()))
		system.util.getLogger(logname).info(' ' * spaces + ml.getProperty('LotStatus').value)
		system.util.getLogger(logname).info(' ' * spaces + ml.getProperty('MaterialRefType').value)
		system.util.getLogger(logname).info(' ' * spaces + ml.getMaterialDefLink().getMESObject().name)
		system.util.getLogger(logname).info(' ' * spaces + ml.getLocationLink().getMESObject().name)
	custlist = ml.getAllCustomProperties()
	if 'Length' in custlist:
		if trace:
			system.util.getLogger(logname).info('Length is present 1')
	if trace:
		system.util.getLogger(logname).info(str(custlist))
	for c in custlist:
		if c.name == 'Length':
			if trace:
				system.util.getLogger(logname).info('Length is present 2')
		if trace:
			system.util.getLogger(logname).info( str(c.value) )
	if str(ml.getLotAvailabilityStatus()) == 'AVAILABLE':
		system.util.getLogger(logname).info("OK-AVAILABLE")
		return 1
	else:
		system.util.getLogger(logname).info("FAIL-%s" % str(ml.getLotAvailabilityStatus()))
		return 0
	
def findChildEquipment(peqp,eqlist):
	parentlinks = peqp.getChildCollection().getList()
	if len(parentlinks) > 0:
	 for item in parentlinks:
		obj = item.getMESObject()
		if str(obj.MESObjectType) in [ 'Equipment Class','EquipmentClass']:
			findChildEquipment(obj,eqlist)
		else:
			eqlist.append(item)
	else:
		childlinks = peqp.getChildCollection().getList()
		for cheq in childlinks:
			obj = cheq.getMESObject()
			if str(obj.MESObjectType) not in [ 'Equipment Class', 'EquipmentClass']:
				eqlist.append(cheq)
				
def findAllowedEquipment(peqp):
	eqlist = []
	if str(peqp.MESObjectType) in [ 'Equipment Class', 'EquipmentClass']:
	 parentlinks = peqp.getChildCollection().getList()
	 if len(parentlinks) > 0:
		for item in parentlinks:
			obj = item.getMESObject()
			if str(obj.MESObjectType) in [ 'Equipment Class', 'EquipmentClass']:
				KO.utils.findChildEquipment(obj,eqlist)
			else:
					eqlist.append(str(item.name).strip())
	 else:
		childlinks = peqp.getChildCollection().getList()
		for cheq in childlinks:
			obj = cheq.getMESObject()
			if str(obj.MESObjectType) not in [ 'Equipment Class','EquipmentClass']:
				eqlist.append(str(cheq.name).strip())
			else:
				KO.utils.findChildEquipment(obj,eqlist)
	else:
			eqlist.append(peqp.name)
	return eqlist
				
def travelMaterialChildren(tdict,aclass,classtype):
	childlinks = aclass.getChildCollection().getList()
	for item in childlinks:
			obj = item.getMESObject()
			tdict[obj.name] = {}
								
			if str(obj.MESObjectType) == classtype:
				KO.utils.travelMaterialChildren(tdict[obj.name],obj,classtype)
										
def travelMaterialResult(adict,result):
	for k in adict.keys():
			if len(adict[k].keys()) == 0:
				result.append(k)
			else:
				result = KO.utils.travelMaterialResult(adict[k],result)
	return result
	
def findAllowedMaterials(materialdef):
	allowed = []
	mref = materialdef.getMaterialRef()
	if materialdef.getMaterialRefType() == 'MaterialClass':
		tdict = {}
		tdict[materialdef.name] = {}
		KO.utils.travelMaterialChildren(tdict[materialdef.name],materialdef.getMaterialRef().getMESObject(),'Material Class')
		allowed = KO.utils.travelMaterialResult(tdict,allowed)
	else:
		allowed = [materialdef.getMaterialRef().getMESObject().name]
	return allowed

def testAllowedMaterial(materialdef):
	print findAllowedMaterials(materialdef)