import BSIF.Boomi
import system
import pprint
import KO
import system
lotname = '443099B7'

def createUnknownLot(lotname):
	try:
		ml = system.mes.loadMaterialLot(lotname,-1,1)
		system.util.getLogger('ERP').info('Lot %s in MES' % lotname)
		print ml
		print ml.name
	except:
		system.util.getLogger('ERP').info('Lot %s NOT in MES' % lotname)
		ldata = KO.erp.isLotInERP(lotname)
		if ldata != None:
			return KO.erp.createLot(ldata,lotname,'Ingot',1,'Ingot Area')
	return 1

def isLotInERP(lotname):
	try:
		ldata = BSIF.Boomi.getRossLotInfoBoomi(lotname)
		#pprint.pprint(ldata)
		#system.util.getLogger('ERP').info('Lot %s in ERP' % lotname)
		return ldata
	except:
		system.util.getLogger('ERP').info('Lot %s NOT in ERP' % lotname)
		return None
		
def createLotAtEquipmentLocation(erpdata,lotname,materialname,materialqty,location):
	system.util.getLogger('ERP').info('createLotAtEquipmentLocation lot: %s type:%s qty:%f loc:%s' % (lotname,materialname,materialqty,location))
	if erpdata == None:
		system.util.getLogger('ERP').info('erpdata is empty. Non-existent erp lot: %s' % lotname)
		return 0
	system.util.getLogger('ERP').info('%s' % erpdata)
	try:
		if materialname == 'Ingot':
			try:
				system.util.getLogger('ERP').info('erp lot exists: %s' % lotname)
				castAlloy = erpdata['LOT']['CHEMISTRY']['ALLOY']
				system.util.getLogger('ERP').info('castAlloy:%s\n' % castAlloy)
				seg = system.mes.createSegment('magically appear', 'Kaiser\KAW\Admin\Planning', True)
				print seg
				pdict = {'castAlloy':castAlloy,'Thickness':0.0,'Length':0.0,'Width':0.0}
				seg.setMaterial('Material Out',materialname,eqpath,lotname,materialqty,pdict)
				print seg
				seg.execute()
				return 1
			except:
				raise
				return 0
	except:
		system.util.getLogger('ERP').info('non-existent erp lot: %s' % lotname)
		return 0


def createLot(ldata,lotname,materialname,materialqty,location):
	eqpath = "Kaiser\KAW\Ingot Prep\Ingot Inventory\Ingot Area"
	system.util.getLogger('ERP').info('unfound mes lot: %s' % lotname)
	try:
		
		if materialname == 'Ingot':
			try:
				system.util.getLogger('ERP').info('erp lot exists: %s' % lotname)
				castAlloy = ldata['LOT']['CHEMISTRY']['ALLOY']
				seg = system.mes.createSegment('magically appear', 'Kaiser\KAW\Admin\Planning', True)
				seg.setMaterial('Material Out',materialname,eqpath,lotname,materialqty,{'castAlloy':castAlloy})
				seg.execute()
				return 1
			except:
				return 0
	except:
		system.util.getLogger('ERP').info('non-existent erp lot: %s' % lotname)
		raise
		return 0