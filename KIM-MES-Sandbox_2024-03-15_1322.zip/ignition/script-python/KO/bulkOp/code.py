import StringIO
import system
def do(baseTagPath,eqPath):
	# do(pitop,pitno,practice):
	print 'DO A PIT OPERATION'
	import KO
	trace = 1
	
	begtag,endtag,optag = system.tag.readBlocking([baseTagPath + '/Interaction/cycleBegin',
		baseTagPath + '/Interaction/cycleEnd',
		baseTagPath + '/Interaction/cycleOperation'])
		
	psName = optag.value
	stop = endtag.value
	start = begtag.value
	
	seg = None

	if trace:
		print ('psName ' + psName )
		print ( 'eqPath ' +  eqPath )
		print ( 'start ' + str( start ) )
		print ('stop ' + str( stop ) )
	
	oper = system.mes.getCurrentOperation(eqPath)
	if oper != None:
		oper.abort()

	print psName
	opdef = KO.OpData.OpDef(psName)
	snap = KO.OpData.TagSnapshot(baseTagPath + '/' + psName)
	ko = KO.baseOp.KaiserOperation(eqPath,baseTagPath,psName)
	
	for mn in ko.materials.keys():
		lobj = ko.materials[mn].properties.getPropertyValue('LotObject')
		qty = ko.materials[mn].properties.getPropertyValue('QOH')
		pn = lobj.getPropertyValue('PartNumber')
		if trace:
			print ('%s %s %s %s' % (ko.materials[mn].lot,qty,pn,lobj.getLotSequence()))
		
	## create segment
		
	seg = system.mes.createSegment(psName, eqPath, 0)
		
	##Begin Segment
	#seg = seg.begin(start)
	if trace:
		print seg
		print 'Response Segment Begun\n'
		
	for matname in ko.materials.keys():
		if trace:
			print 'loop'*10
			print matname
			outmatname = matname.replace('In','Out')
		if trace:
			print outmatname
			print ko.materials[matname].matdef.use
			
			##i = 0
			##mNameIn = ''
			##for lno in lotdict.keys():
			#lmat = system.mes.loadMaterialLot(lno, -1, 0)
			#qty = float( lmat.getLotInventory().getNetQuantity() )
		
			#mNameIn = 'Material In %02d' % (i + 1)
			#mNameIn = 'Material In'
			#if psName != 'autoSOAK':
			#	seg.setMaterial(mNameIn,lno, -1, 1.0)
			#else:
			#	seg.setMaterial(mNameIn,lno, -1, qty)
		if ko.materials[matname].matdef.use == 'In':
		 try:
			if trace:
				print 'IN %s- %s %s' % (matname,ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
			seg.setMaterial(matname,ko.materials[matname].lot,-1,ko.materials[matname].properties.getPropertyValue('QOH'))
			# since only material inputs are defined in the field they must be created in this script
			if psName in ['autoSR','autoPHP']:
				if trace:
					print 'OUT: %s- %s %s %s %f' % (outmatname,'Ingot','Kaiser\KAW\Ingot Prep\Ingot Inventory\Ingot Yard',ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
					seg.setMaterial(outmatname,'Ingot','Kaiser\KAW\Ingot Prep\Ingot Inventory\Ingot Yard',ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
			if psName == 'autoSOAK':
				if trace:
					print 'OUT: %s- %s %s %s %f' % (outmatname,'Rolling Ingot',eqPath,ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
				seg.setMaterial(outmatname,'Rolling Ingot',eqPath,ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
			#print ( mNameIn, lno )
			
			#mName = 'Material Out %02d' % (i + 1)
			##mName = 'Material Out'
			#print mName
			#if psName != 'autoSOAK':
			#	seg.setMaterial(mName, 'Ingot', eqPath, lno, 1.0)
			#	#seg.setMaterial(mName,1.0)
			#else:
			#	# material quantity must be
			#	seg.setMaterial(mName, 'Rolling Ingot', eqPath, lno, qty)
			#i = i + 1
			#if ko.materials[matname].matdef.use == 'OUT':
			#	if psName == 'autoSR':
			#		print 'OUT:'
			#		seg.material(matname,'Ingot','Kaiser\KAW\Ingot Prep\Ingot Inventory\Ingot Yard',ko.materials[matname].lot,ko.materials[matname].properties.getPropertyValue('QOH'))
		 except:
			pass

	print seg
	print psName
	print start	
	#Commit the changes
	seg = seg.begin(start)
	#seg = seg.update()
	skip = """
		print seg
		print 'Response Segment Updated\n'
		
		for lno in lotdict.keys():
			try:
					lobj = system.mes.loadMaterialLot(lno, -1, 0)
					lobj.addCustomProperty('currentPartNumber','String')
					lobj.setPropertyValue('currentPartNumber','%s' % lotdict[lno]['partno'])
					print ( lobj )
					print ( system.mes.saveMESObject(lobj) )
					
			except:
					# this should be the normal case
					print (lno,' not found')
					raise
			i = i + 1
	"""
	for matname in ko.materials.keys():
			if ko.materials[matname].matdef.use == 'In':
				ml = system.mes.loadMaterialLot(ko.materials[matname].lot,-1,0)
				lml = system.mes.loadMaterialLot(ko.materials[matname].lot,ml.getLotSequence() - 1,0)
				pn = lml.getPropertyValue('PartNumber')
				ml.addCustomProperty('PartNumber','String')
				ml.setPropertyValue('PartNumber',pn[0:-2] + psName[4:])
				ml.addCustomProperty('LastOp','String')
				ml.setPropertyValue('LastOp',psName)
				system.mes.saveMESObject(ml)
				
	seg = seg.update()
	if trace:
		print 'Ending response segment'
	#End the segment
	seg = seg.end(stop)
	if trace:
		print seg
		print 'Response Segment Ended\n'
		
def bulkMove(fromeq,toeq,movemat):
	#this are equipment paths as shown below
	print 'BULK MOVE %s' % movemat
	#fromeq = event.source.parent.getComponent('BulkFrom').equipmentItemPath
	#toeq = event.source.parent.getComponent('BulkTo').equipmentItemPath
	#movemat = event.source.parent.getComponent('BulkType').selectedName
	#finalstatus = event.source.parent.getComponent('BulkFinalStatus').text
	finalstatus = ''
		
	lotnumbers = []
	moveduration = 5
	if movemat == 'Volatile Ingot':
		eqPath = 'Kaiser\KAW\Casting\Transport\Trucks\Ingot Safe Transport'
		psName = 'Move Volatile Ingot'
		moveduration = 10
	if movemat == 'Ingot':
		eqPath = 'Kaiser\KAW\Casting\Transport\Trucks\Ingot Transport'
		psName = 'Move Ingot To Yard'
		moveduration = 5
		
	moveend = system.date.now()
	movestart = system.date.addMinutes(moveend, -moveduration)
	lotinv = []
			
	# now find all output material associated with
	# the last response segment
	lotenv = system.mes.getLotInventoryByEquipment(fromeq,1)
		
	for item in lotenv:
		print item.getLotNumber()
		lno = item.getLotNumber()
		luuid = item.getMaterialLotUUID()
		mname = item.getMaterialName()
		castAlloy = ''
		print mname
			
		ml = system.mes.loadMaterialLot(lno,-1,0)
		pn = 'unknown'
		lastop = 'unkown'
		try:
			pn = ml.getPropertyValue('PartNumber')
			resid = ml.getPropertyValue('ResponseSegmentUUID')
			lastop = system.mes.getMESObjectLink(resid).getMESObject().name
		except:
			raise
			
		print movemat	
		if mname == movemat:
			try:
				oper = system.mes.getCurrentOperation(fromeq)
				if oper != None:
					oper.abort()
			except:
				pass
			## create segment		
			seg = system.mes.createSegment(psName, eqPath, 0)
		
			##Begin Segment
			#seg = seg.begin(movestart)
			print seg
			print 'Response Segment Begun\n'
		
			seg.setMaterial('Material In', lno, 1.0)
			seg.setMaterial('Material Out', mname, toeq, lno, 1.0)
					
			#Commit the changes
			#seg = seg.update()
				
			##Begin Segment
			seg = seg.begin(movestart)
		
			mlo = system.mes.loadMaterialLot(lno, -1, 0)
			mlo.addCustomProperty('PartNumber','String','','',True,False)
			mlo.setPropertyValue('PartNumber',pn)
			mlo.addCustomProperty('LastOp','String','','',True,False)
			mlo.setPropertyValue('LastOp',lastop)
			system.mes.saveMESObject(mlo)
		
			print seg
			if len(finalstatus) > 0:
				#ml = seg.getMaterialLot('Material Out')
				#ml.setPropertyValue('LotStatus',finalstatus)
				seg.getComplexProperty('ResponseMaterial','Material Out').setFinalLotStatus(finalstatus)
				#system.mes.saveMESObject(ml)
				print 'Material Out Updated\n'
				seg = seg.update()
				
			print 'Ending response segment'
			#End the segment
			seg = seg.end(moveend)
			print seg
			print 'Response Segment Ended\n'