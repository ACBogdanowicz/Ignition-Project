def test():
	KO.Wagon.start('Wagon 107')
	print 'started'
	KO.Wagon.addMaterial('Wagon 107','lotA',1000.0)
	print 'endA'
	KO.Wagon.addMaterial('Wagon 107','lotB',1000.0)
	print 'endB'
	KO.Wagon.addMaterial('Wagon 107','lotC',1000.0)
	print 'endC'

def start(wagonId):

	seg = system.mes.createSegment('wagonTransport','Kaiser\KAW\Admin\Handling',0)
	seg = seg.begin()

def addMaterial(wagonId,lotnum,qty):
	op = system.mes.getCurrentOperation('Kaiser\KAW\Admin\Handling')
	segname = op.getActiveSegmentName()
	seg = op.getActiveSegment(segname)
	seg.setMaterial('plate','Plate',wagonId,lotnum,qty)
	seg.update()

def removeMaterial(wagonId):
	op = system.mes.getCurrentOperation(Handling)
	seg = op.getCurrentSegment()
	lot = system.mes.getMaterialLotNextAvailable(seg,'plate','*')
	seg.update()
	