import system
import os,time
from com.inductiveautomation.ignition.common.model.values import BasicQualifiedValue
import utils
import StringIO

def sandbox():
  import KO
  oper = system.mes.getCurrentOperation('Kaiser\KAW\Sandbox\SandboxLine')
  if oper != None:
  	oper.abort()
  ko = KO.baseOp.KaiserOperation('Kaiser\KAW\Sandbox\SandboxLine',
  	'[MES_Tags]Sandbox/SandboxLine/mes')
  endts = system.date.now()
  startts = system.date.addMinutes(endts,-10)
  print 'zxzxzx'
  oper = system.mes.getCurrentOperation('Kaiser\KAW\Sandbox\SandboxLine')
  if oper != None:
  	oper.abort()
  ko.prepareSegment()
  ko.copySegmentPropertyToOutputMaterials('partNumber','PartNumber')
  ko.execute(startts,endts)
  
  return ko

class  OperationMaterial():
 def __init__(self,ko,matname,matdef,matfld):
 	self.trace = 1
 	self.lot = None
 	self.quantity = 0.0
 	self.materialdefname = None
 	self.equipmentname = ko.equip.name
 	self.materialequipment = ko.equip
 	self.ko = ko
 	self.finalstatus = None
 	self.equip = None
 	self.name = matname
 	self.matdef = matdef
 	self.matfld = matfld
 	self.eqpath = ko.eqpath
 	self.lotobj = None
 	self.properties = KO.OpData.KOPropertyList('Op Material "%s" Properties' % self.name)

 	for key in self.matfld.properties.keys():
 		if key not in self.properties.keys():
 			if key == 'Lot':
 				self.lot = matfld.properties.getPropertyValue(key)
 			elif key == 'MaterialName':
 			 	self.materialdefname = matfld.properties.getPropertyValue(key)
 			elif key == 'Quantity':
 			 	self.quantity = matfld.properties.getPropertyValue(key)
			else:	
 				self.properties.addProperty(self.matfld.properties.getProperty(key))

 	for key in self.matdef.properties.keys():
 		if key not in ['Lot','MaterialName','Quantity']:
 			if key not in self.matfld.properties.keys():
 				self.properties.addProperty(self.matdef.properties.getProperty(key))
 		 
 def setFinalLotStatus(self,statustext):
 	self.finalstatus = statustext
 
 def populateSegmentMaterial(self,seg):
 	if self.matdef.use == 'In':
 		if self.trace:
 			print 'PSM input'
 			print self.name
 		seg.setMaterial(self.name,self.lot,-1,self.quantity)
 	if self.matdef.use == 'Out':
 	 if self.finalstatus != None:
 		seg.getComplexProperty('ResponseMaterial',self.name).setFinalLotStatus(self.finalstatus)
	 if self.matdef.autogeneratelot == False:
	 	if self.trace:
			print 'PSM not autogeneratelot'
			print self.name
 		seg.setMaterial(self.name,self.lot,-1,self.quantity)
 	 else:
 	 	if self.trace:
 	 		print 'PSM auto generate'
 			print self.name
 			print self.materialdefname
 			print self.eqpath
 			#print self.materialequipment
 			#print self.materialequipment.getEquipmentPath()
 			print self.lot
 			print self.quantity
 			self.show()
 		#'Kaiser\KAW\Casting\DC1\DC1-Pit',
 		try:
 		 seg.setMaterial(
 			self.name,
 			self.materialdefname,
 			self.eqpath,
 			self.lot,
 			self.quantity)
 		except:
 		 if self.trace:
 		 	raise
 		 raise	Exception('populateSegmentMaterial exceptions')



 def updateSegmentMaterialLotProperties(self,seg):
 	if self.trace:
 		print seg.getUUID()
 	
	if self.matdef.use == 'Out':
		if self.trace:
			print 'USMLP ' + self.lot
			self.properties.show()
		lotpropnames = []
		if(self.lot) > 6:
		 try:		
			self.lotobj = system.mes.loadMaterialLot(self.lot,-1,0)
			cplist = self.lotobj.getAllCustomProperties()
			for item in cplist:
				lotpropnames.append(item.name)
			for name in self.properties.keys():
				if name in lotpropnames:
					# required property
					self.lotobj.setPropertyValue(name,self.properties.getPropertyValue(name))
				else:
					self.lotobj.addCustomProperty(name,'String','','',True,False)
					self.lotobj.setPropertyValue(name,self.properties.getPropertyValue(name))
					
			self.lotobj.addCustomProperty('LastOp','String')
			self.lotobj.setPropertyValue('LastOp',self.ko.opname)
					
			system.mes.saveMESObject(self.lotobj)
		 except:	
			pass
			
 def show(self,spaces = 0):
 	print ' ' * spaces + 'OperationMaterial:"%s"' % self.name
 	print ' ' * spaces + 'Lot: <%s> Material: <%s> Quantity: <%s>' % (self.lot,self.materialdefname,self.quantity)
 	print ' ' * spaces + 'Material Eq Path: <%s>' % self.eqpath
 	self.properties.show(spaces + 3)
 	
 def toLogger(self,logger,spaces = 0):
 	logger.info(' ' * spaces + 'OperationMaterial:"%s"' % self.name)
	logger.info(' ' * spaces + 'Lot: <%s> Material: <%s> Quantity: <%s>' % (self.lot,self.materialdefname,self.quantity))
	logger.info(' ' * spaces + 'Material Eq Path: <%s>' % self.eqpath)
	self.properties.toLogger(logger,spaces + 3)

 def asString(self,spaces = 0):
 	rstr = StringIO.StringIO()
 	rstr.write('%s\n' % ( ' ' * spaces + 'OperationMaterial:"%s"' % self.name))
 	rstr.write('%s Lot: <%s> Material: <%s> Quantity: <%s>\n' % ( ' ' * spaces, self.lot,self.materialdefname,self.quantity))
 	rstr.write('%s Material Eq Path: <%s>\n' % ( ' ' * spaces, self.eqpath))
 	rstr.write('%s' % (self.properties.asString(spaces + 3)))
 	return rstr.getvalue()
 	
class KaiserOperation():
 def __init__(self,eqpath,basetagpath,manopname = None):
 	self.pid = os.getpid()
	self.tlogger = system.util.getLogger('KaiserOperation')
	self.tlogger.info('KO ' + str(self.pid) + ' __init__ ' + str(eqpath) + ' ' + str(basetagpath))
 	self.trace = 1
 	self.bypassEquipment = 1
 	if self.trace:
 		print 'begin initialization'
 	self.created = system.date.now()
 	self.eqpath = eqpath
 	self.basetagpath = basetagpath
 	self.opname = None
 	self.finallotstatus = None
 	self.equipdef = None
	self.equip = system.mes.getMESObjectLinkByEquipmentPath(self.eqpath)
	self.materials = None
	
	if manopname == None:
 		self.opname = system.tag.readBlocking([ basetagpath + '/Interaction/cycleOperation'])[0].value
 		if self.trace:
 			print self.opname
 	else:
 		self.opname = manopname
 		
	self.tlogger.info('KO ' + str(self.pid) + ' __init__ ' + str(self.opname))
	
 	self.roottagpath = self.basetagpath + '/' + self.opname
 	# what if the ko is being created after the initial creation... shouldn't the segment be set too?
 	self.seg = None
 	
 	self.optagpath = self.basetagpath + '/' + self.opname
 	self.tagsnapshot = KO.OpData.TagSnapshot(self.optagpath)
 	if self.trace:
 		print 'init tagsnapshot'
 	self.tagsnapshot.properties.show()
 	self.operationdef = KO.OpData.OpDef(self.opname)
 	if self.trace:
 		print 'init opdef'
 	self.operationdef.properties.show()
 	self.setOperationProperties()
 	if self.trace:
 		print 'init post setOperationProperties'
 	self.properties.show()
 	
 	#self.getDefinition()
 	#self.getField()
 	if self.trace:
 		print self.operationdef.opdef.name
 		print KO.utils.findAllowedEquipment(self.operationdef.opdef)
 		print 'check'
 	if self.equip.name not in KO.utils.findAllowedEquipment(self.operationdef.opdef.getEquipment()):
 		if self.trace:
 			print KO.utils.findAllowedEquipment(self.operationdef.opdef.getEquipment())
 		if not self.bypassEquipment:
 			raise Exception('Equipment %s specified not allowed to run this operation (%s).' % (self.equip.name,self.opname))
 		pass
 	if self.trace:
 		print 'init setOperationMaterials'
 	self.setOperationMaterials()
 	if self.trace:
 		print 'end initialization'
 	self.tlogger.info('KO ' + str(self.pid) + ' __init__ end')
 			
 def setOperationProperties(self):
 	self.properties = KO.OpData.KOPropertyList('Operation "%s" Segment Properties' % self.opname)
 	for k in self.tagsnapshot.properties.keys():
 		self.properties.addProperty(self.tagsnapshot.properties.getProperty(k))
 	for k in self.operationdef.properties.keys():
 		if k not in self.properties.keys():
 			self.properties.addProperty(self.operationdef.properties.getProperty(k))
 		else:
 			# override the default values if there is an existing tag with the same name
 			self.properties.setPropertyValue(k,self.tagsnapshot.properties.getPropertyValue(k))


 def setMaterialPropertyValue(self,matname,name,value,setfield=0):
 	if matname in self.matproperties.keys():
 		matfieldprops = self.matproperties[matname]
 		self.setPropertyValue(matfieldprops,name,value,setfield)
 		
 def updateSegmentMaterialProperties(self):
 	for matname in self.materials.keys():
 		self.materials[matname].updateSegmentMaterialLotProperties(self.seg)
 		
 def setSegmentPropertyValue(self,name,value,setfield=0):
 	self.setPropertyValue(self.properties,name,value,setfield)
 	
 def setPropertyValue(self,propdict,name,value,setfield=0):
 	# if there is defined property of name set it.
 	# else if there is a field property set it.
 	# if setfield is true and the name is in thefield values set the field value (plc update).
 	if name in propdict.keys():
 			# the property exists
 			propdict[name]['value'].value = value
 			if setfield == 1:
 				fullpath = propdict[name]['fullPath']
 				system.tag.writeBlocking([str(fullpath)],[value])
 	else:
 		# the property is new
 		# you can't set a field value of something not in the field
 		# this would be where you put code to create a pseudo tag
 		propdict[name] = {}
 		if type(value) == float:
 			propdict[name]['dataType'] = 'Float4'
 		elif type(value) == int:
 			propdict['dataType'] = 'Int4'
 		else:
 			propdict[name]['dataType'] = 'String'
 		propdict[name]['value'] = BasicQualifiedValue(value)
 		
 def copySegmentPropertyToOutputMaterials(self,segpropname,matpropname):
 	value = self.properties.getPropertyValue(segpropname)
 	for mat in self.materials.keys():
 		if self.materials[mat].matdef.use == 'Out':
 			matfieldprops = self.materials[mat].properties
 			
 			if matpropname in matfieldprops.keys():
 				matfieldprops.setPropertyValue(matpropname,value)
 			else:
 				sprop = self.properties.getProperty(segpropname)
 				sprop.name = matpropname
 				matfieldprops.addProperty(sprop)

 def setOperationMaterials(self):
 	self.materials = {}
  	for matname in self.tagsnapshot.materials.keys():
  	 try:
  		result = self.materialCheck(matname)
  		if result != None:
  			self.materials[matname] = result
  	 except:
  	 	pass
  	 	#raise
 
 def materialCheck(self,matname):
  	fldmat = self.tagsnapshot.materials[matname]
 	defmat = self.operationdef.materials[matname]
 	fldmat.properties.show()
 	defmat.properties.show()
 	
 	opmat = OperationMaterial(self,matname,defmat,fldmat)
 	if self.trace:
 		print 'exc'*10
 	eqtype = str(defmat.matdef.getEquipmentRefType())
 	if eqtype != 'EquipmentClass':
 		if self.trace:
 			print str(defmat.matdef.getEquipmentRefType())
 			print str(defmat.matdef.getEquipmentRef())
 			print str(defmat.matdef.getEquipmentRefUUID())
 		opmat.eqpath = str(system.mes.getMESObjectLink(defmat.matdef.getEquipmentRefUUID()).getMESObject().getEquipmentPath())
 	else:
 		if self.trace:
 			print 'equipment class present'
 	if self.trace:	
 		print 'cxe'*10

	# for any optional material if there is no lot number then ignore it
	if opmat.lot == None:
		return None
 	if len(opmat.lot) < 6 and defmat.optional:
 		return None
 	
 	ml = None
 	qoh = 0.0
 	if len(opmat.lot) > 6 and defmat.use == 'In':
 		#check to make sure that the lot exists and has quantity otherwise raise and exception
 		try:
 			ml = system.mes.loadMaterialLot(opmat.lot,-1,1)
 			lotavailability = str(ml.getLotAvailabilityStatus())
 			if lotavailability != 'AVAILABLE':
 				raise Exception('material lot %s not available (%s).' % (opmat.lot,opmat.name))
 			qoh = ml.getLotInventory().getNetQuantity()
 			mloc = ml.getLocationLink().getMESObject().name
 			print 'mloc %s\n' % mloc
 			opmat.equipmentname = ml.getLocationLink()
 			mls = ml.getPropertyValue('LotStatus')
 			opmat.properties.createProperty('LotObject','object', ml)
 			opmat.properties.createProperty('QOH','Float',qoh)
 			opmat.properties.createProperty('MaterialLocationName','string',mloc)
 			opmat.properties.createProperty('LotStatus','string', mls)
 		except:
 			raise
 			raise Exception('material lot %s not found for use in %s' % (lot,matname))
	if self.trace:
		print 'ref'*20
	eqreftype = str(defmat.matdef.getEquipmentRefType())
	print eqreftype
	print eqreftype
  	if eqreftype == 'EquipmentClass':
 		_equip = system.mes.getMESObjectLinkByName('EquipmentClass',defmat.matdef.getEquipmentRef().name).getMESObject()
	elif eqreftype == 'StorageUnit':
 		_equip = defmat.matdef.getEquipmentRef()
 		opmat.eqpath = _equip.getMESObject().getEquipmentPath()
 	else:
 		_equip = defmat.matdef.getEquipmentRef()

	print _equip.name
 	
 		
 	#equipmentname = self.equip.name
 	eqallowed = KO.utils.findAllowedEquipment(_equip)

 	if len(eqallowed) == 1:
 		opmat.equipmentname = eqallowed[0]
 	if 'EquipmentName' in fldmat.properties.keys():
 			opmat.equipmentname = self.fldmat.properties.getPropertyValue('EquipmentName')

 	if opmat.equipmentname not in eqallowed:
 		if self.trace:
 			print eqallowed
 			print ('Equipment >%s< not allowed in %s.' % (opmat.equipmentname,matname))
 		#raise Exception('Equipment %s not allowed in %s.' % (opmat.equipmentname,matname))

 	# is the output material type allowed?
 	if self.trace:
 		print 'is the output material allowed'
 	materialname = ''
 	materialref = defmat.matdef.getMaterialRef()
 	if self.trace:
 		print (materialref)
 	if str(materialref.MESObjectType) == 'Material Definition':
 			opmat.materialdefname = materialref.name
 	if 'MaterialName' in fldmat.properties.keys():
 		opmat.materialdefname = fldmat.properties.getPropertyValue('MaterialName')
 	if opmat.materialdefname == None:
 		opmat.materialdefname = ml.getMaterialDefLink().name
 	if opmat.materialdefname not in KO.utils.findAllowedMaterials(defmat.matdef):
 		if self.trace:
 			print KO.utils.findAllowedMaterials(defmat.matdef)
 			print ('Material %s not allowed in %s.' % (opmat.materialdefname,matname))
 		raise Exception('Material %s not allowed in %s.' % (opmat.materialdefname,matname))
 	if self.trace:
 		print 'is there quantity'
 	quantitysource = defmat.matdef.getQuantitySource()
 	quantity = quantitysource
 	# if quantitysource is equal to 'Link' expect the system to handle it
 	# if manual then a Quantity should be specified or the default in the material definition is used.
 	if quantitysource == 'Manual':
 		#print 'qs manual',str(defmat.getQuantity())
		quantity = defmat.matdef.getQuantity()
 	if 'Quantity' in fldmat.properties.keys():
 		#print 'qs Quantity'
 		quantity = fldmat.properties.getPropertyValue('Quantity')
 		
 	skip="""
 	if len(opmat.lot) > 6 and defmat.use == 'Out':
 		#opmat.properties.createProperty('OutputLocationName','string', equipmentname)
 		#opmat.properties.createProperty('OutputQuantity','Float', quantity)
 		if 'MaterialName' not in opmat.properties.keys():
 			opmat.properties.createProperty('MaterialName','string', opmat.materialdefname)
 		else:
 			opmat.properties.setPropertyValue('MaterialName',opmat.materialdefname)
 	"""
 	if self.trace:
 		print 'end materialCheck'
 	return opmat

 def setSegmentProperties(self):
 	if self.seg != None:
 		for name in self.properties.keys():
 			if name not in self.operationdef.properties.keys():
 				self.seg.addCustomProperty(name,self.properties.getPropertyDataType(name),'','',True,False)
 				self.seg.setPropertyValue(name,self.properties.getPropertyValue(name))
 			else:
 				self.seg.setPropertyValue(name,self.properties.getPropertyValue(name))
 					 	
 def createSegment(self):
 	# creates a segment with no commitment until a start or end is called
 	# perform a check to make sure that the operation can run at this piece of equipment
 	# this check is done upon creation of the KaiserOperation object in the init function
 	#if not self.operationAllowed:
 	#	return Noneoper = system.mes.getCurrentOperation(equipmentpath)
 	self.tlogger.info('createSegment start')
	oper = system.mes.getCurrentOperation(self.eqpath)
 	if oper != None:
 		segName = oper.getActiveSegmentName()
 		if self.trace:
 			print 'Operation >%s< is executing on >%s' % (segName,self.eqpath)
 		self.tlogger.info('Operation >%s< is executing on >%s' % (segName,self.eqpath))
 		oper.abort()
	try:
 		seg = system.mes.createSegment(self.opname, self.eqpath, True)
 		self.seg = seg
 		return seg
	except:
		self.tlogger.info('createSegment error >%s< is executing on >%s' % (segName,self.eqpath))
		self.abortSegment()
		try:
			self.seg = system.mes.createSegment(self.opname, self.eqpath, True)
			return self.seg
		except:
			self.tlogger.info('createSegment error >%s< is executing on >%s' % (segName,self.eqpath))
			raise
	self.tlogger.info('createSegment done')
 			
 def abortSegment(self):
 	# this will clear the segment created by createSegment
 	# it will abort an operation if there is one active on the piece of equipment
 	# make sure you take this into account because some pieces of equipment
 	# have multiple active response segments
 		
 	oper = system.mes.getCurrentOperation(self.eqpath)
 	if self.trace:
 		print oper
 	if oper != None:
 		segname = oper.getActiveSegmentName()
 		oper.abort()
 		self.seg = None
 	else:
		self.seg = None
		
 def setSegmentMaterials(self):
	for matname in self.materials.keys():
		self.materials[matname].populateSegmentMaterial(self.seg)

 def prepareSegment(self):
 	# this pseudo code in complex cases

 	self.setOperationProperties()
 	self.setOperationMaterials()
 	# at this point make change to operation and material properties
 	# if it is a complex case and calculations need to be made
 	# or changes to material types, location or quantities if the 
 	# operation segment uses classes instead of specific values
 	self.seg = self.createSegment()
	self.setSegmentProperties()
	self.setSegmentMaterials()
 	
 def execute(self,begints,endts):
 	try:
 		#self.setMaterialResult()
 		#self.prepareSegment()
 		self.seg = self.seg.begin(begints)
 		for matname in self.materials.keys():
 			self.materials[matname].populateSegmentMaterial(self.seg)
 		if self.finallotstatus != None:
 			self.seg.LotStatus(self.finallotstatus)
 		self.seg = self.seg.update()
 	except:
 		#raise Exception('execute error')
 		raise
 		
 	#self.seg = self.seg.begin(begints)
 	for matname in self.materials.keys():
 		if self.trace:
 			print 'ZZZZZZZZZZZZZZZZZZZZZZZ %s ZZZZZZZZZZZ' % matname
 			self.materials[matname].show()
 		self.materials[matname].updateSegmentMaterialLotProperties(self.seg)
 			
 	#self.seg = self.seg.update()
 	system.mes.updateSegment(self.seg)
 	#self.seg.end(endts)
 	system.mes.endSegmentWait(self.seg)
 	oper = system.mes.getCurrentOperation(self.eqpath)
 	system.mes.endOperation(self.eqpath,oper)
 	
 	
 def show(self,spaces = 0):
 	print ' ' * spaces + 'KO-' * 20
 	print ' ' * spaces + 'Kaiser Operation'
 	print ' ' * spaces + self.eqpath
 	print ' ' * spaces + self.basetagpath
 	print ' ' * spaces + 'KO-' * 5
 	self.properties.show(spaces + 3)
 	self.operationdef.properties.show(spaces + 10)
 	self.tagsnapshot.properties.show(spaces + 10)
 	for m in self.materials.keys():
 		self.materials[m].show(spaces + 6)
 	print ' ' * spaces + 'KO-' * 20 + 'kaiseroperation'

 def toLogger(self,logger,spaces = 0):
	logger.info(' ' * spaces + 'KO-' * 20)
	logger.info(' ' * spaces + 'Kaiser Operation')
	logger.info(' ' * spaces + self.eqpath)
	logger.info(' ' * spaces + self.basetagpath)
	logger.info(' ' * spaces + 'KO-' * 5)
 	self.properties.toLogger(logger,spaces + 3)
 	self.operationdef.properties.toLogger(logger,spaces + 10)
	self.tagsnapshot.properties.toLogger(logger,spaces + 10)
	for m in self.materials.keys():
		self.materials[m].toLogger(logger,spaces + 6)
 	logger.info(' ' * spaces + 'KO-' * 20 + 'kaiseroperation')
 	
 def asString(self,spaces = 0):
  	rstr = StringIO.StringIO()
  	rstr.write('%s\n' % ( ' ' * spaces + 'KO-' * 20 ))
	rstr.write('%s\n' % ( ' ' * spaces + 'Kaiser Operation' ))
	rstr.write('%s\n' % ( ' ' * spaces + self.eqpath ))
	rstr.write('%s\n' % ( ' ' * spaces + self.basetagpath))
	rstr.write('%s\n' % ( ' ' * spaces + 'KO-' * 5 ))
	rstr.write('%s' % self.properties.asString(spaces + 3))
	rstr.write('%s' % self.operationdef.properties.asString(spaces + 10))
	rstr.write('%s' % self.tagsnapshot.properties.asString(spaces + 10))
	for m in self.materials.keys():
		rstr.write('zzzz%s\n' % m)
		rstr.write('%s' % self.materials[m].asString(spaces + 6))
	rstr.write('%s\n' % (' ' * spaces + 'KO-' * 20 + 'kaiseroperation'))
	return rstr.getvalue()
 	
 def showSeg(self):
 	print 'showSeg'
 	print self.seg.getEquipmentLink().name
 	acp = self.seg.getAllCustomProperties()
 	for cp in acp:
 		print cp
 		
 	cnt = self.seg.getComplexPropertyCount('ResponseMaterial')
 	print cnt
 	for i in range(cnt):
 		item = self.seg.getComplexProperty('ResponseMaterial',i)
 		try:
 			ml = self.seg.getMaterialLot(item.name)
 			print 'Item: ' + item.name
 			print ml.name
 			for pi in ml.getCustomProperties():
 				print pi
 				print ' ' + str( ml.getPropertyValue(pi))
 		except:
 			pass
 	skip="""		,
 			print 'MaterialName: ' + item.getMaterialRef.name
 			print 'Output Location: ' + item.getLocationRef.name
 			self.ko.eqpath,
 			self.lot,
 			self.quantity)"""
 			
 def segAsString(self):
 	rstr = StringIO.StringIO()
 	rstr.write('segAsString\n')
 	rstr.write('%s\n' % self.seg.getEquipmentLink().name)
	acp = self.seg.getAllCustomProperties()
	for cp in acp:
 		rstr.write('%s\n' % cp)
	cnt = self.seg.getComplexPropertyCount('ResponseMaterial')
	rstr.write('Response Material Count:%s\n' % str( cnt ))
	for i in range(cnt):
		item = self.seg.getComplexProperty('ResponseMaterial',i)
		try:
			ml = self.seg.getMaterialLot(item.name)
			rstr.write('Item: \n' %  item.name )
			rstr.write('%s\n' % ml.name)
			for pi in ml.getCustomProperties():
				rstr.write('%s\n' % pi)
				rstr.write('%s\n' % ml.getPropertyValue(pi))
		except:
			rstr.write('exceptino in response material loop\n')
			pass
	return rstr.getvalue()
	
 def segToLogger(logger,spaces = 0):
		logger.info ('showSeg')
		logger.info (self.seg.getEquipmentLink().name)
		acp = self.seg.getAllCustomProperties()
		for cp in acp:
			logger.info(cp)
			
		cnt = self.seg.getComplexPropertyCount('ResponseMaterial')
		logger.info( cnt )
		for i in range(cnt):
			item = self.seg.getComplexProperty('ResponseMaterial',i)
			try:
				ml = self.seg.getMaterialLot(item.name)
				logger.info( 'Item: ' + item.name )
				logger.info( ml.name )
				for pi in ml.getCustomProperties():
					logger.info( pi )
					logger.info( ' ' + str( ml.getPropertyValue(pi)))
			except:
				pass
		skip="""		,
				print 'MaterialName: ' + item.getMaterialRef.name
				print 'Output Location: ' + item.getLocationRef.name
				self.ko.eqpath,
				self.lot,
				self.quantity)"""
