from com.inductiveautomation.ignition.common.model.values import BasicQualifiedValue
from com.inductiveautomation.ignition.common.sqltags.model.types import DataType

class Property():
 def __init__(self,item,name,datatype,value):
 	self.obj = item
 	self.name = name
 	self.datatype = datatype
 	skip="""
 	try:
 		fullPath = item['fullPath']
 		self.datatype = datatype
 	except:
 		self.datatype = 'String'
 		pass
 	"""
 	self.value = value
 	
 def show(self,spaces = 0):
 	print ' ' * spaces + '%20s %20s %20s' % (self.name,self.value,self.datatype)
 	
class KOPropertyList():
 def __init__(self,title = 'no title'):
 
 	self.title = title
 	self.properties = {}
 	
 def addProperty(self,prop):
 	if prop.name not in self.properties.keys():
 		self.properties[prop.name] = prop
 	else:
 		raise
 		raise Exception('Duplicate property %s for PropertyList' % prop.name)
 		
 def getProperty(self,name):
 	return self.properties[name]
 	
 def createProperty(self,name,dtype,avalue):
 	if name not in self.properties.keys():
 		self.properties[name] = KO.OpData.Property(None,name,dtype,avalue)
 	else:
 		raise Exception('Duplicate property exists for %s' % name)
 		
 def keys(self):
 	return self.properties.keys()
 	
 def setPropertyValue(self,name,avalue):
 	self.properties[name].value = avalue
 	
 def getPropertyValue(self,name):
 	return self.properties[name].value
 	
 def getPropertyDataType(self,name):
 	return self.properties[name].datatype
 	
 def show(self,spaces = 0):
 	print ' ' * spaces + self.title
 	for k in self.properties.keys():
 		self.properties[k].show(spaces+3)
 	print ' ' * spaces + '------------------------------------------------opdef'
  	
class OpDefMaterial():
 def __init__(self,matdef):
 	self.matdef = matdef
 	self.optional = matdef.getOptional()
 	self.autogeneratelot = matdef.getAutoGenerateLot()
 	self.use = matdef.getUse()
 	self.properties = KO.OpData.KOPropertyList('Material "%s" Defined Properties' % matdef.name)
 	
	itemcusprop = self.matdef.getAllCustomProperties()
	for ie in itemcusprop:
		self.properties.addProperty(KO.OpData.Property(ie,ie.name,ie.getDataType(),ie.getValue()))
		
 def show(self,spaces=0):
 	print ' ' * spaces + '------------------------------------------------------------'
 	print ' ' * spaces  + '%20s' % self.matdef.name
 	print ' ' * spaces + str(self.optional)
 	print ' ' * spaces + str(self.autogeneratelot)
 	print ' ' * spaces + self.use
 	self.properties.show(spaces + 3)
 	print ' ' * spaces + '-------------------------------opdef material'
		 
class OpDef():
 def __init__(self,opname):
 	self.init_ts = system.date.now()
	trace = 0
	self.properties = KOPropertyList('OpDef %s Defined Properties' % opname)
	self.materials = {}
	self.matproperties = {}
 
	self.opdef = system.mes.getMESObjectLinkByName('OperationsSegment',opname).getMESObject()
	if trace: print opdef
	custprops = self.opdef.getAllCustomProperties()
	for each in custprops:
		self.properties.addProperty( KO.OpData.Property(each,each.name,each.getDataType(),each.getValue()))
		
	if trace: print self.opdef.getEquipment()

	cnt = self.opdef.getComplexPropertyCount('Material')
	for i in range(cnt):
		item = self.opdef.getComplexProperty('Material',i)
		self.materials[item.name] = KO.OpData.OpDefMaterial(item)
		
 def show(self,spaces = 0):
 	print ' ' * spaces + '===================================================================='
 	print ' ' * spaces + 'OpDef Segment Properties--------------------------------------------'
 	self.properties.show(spaces + 3)
 	for m in self.materials.keys():
 		self.materials[m].show(spaces + 6)
 		
		
def testOpDef(opname):
	opd = KO.OpData.OpDef(opname)
	opd.show(5)

class TagMaterial():
 def __init__(self,tagresult):
 	self.tagresult = tagresult
 	self.properties = KOPropertyList('TagMaterial %s Properties' % self.tagresult['name'])
 	pywrap = system.tag.browse(self.tagresult['fullPath'])
 	results = pywrap.getResults()
 	for result in results:
 		#print 'ippy ',str(result['name']),str(presult['name']), str(presult)
 		self.properties.addProperty( KO.OpData.Property(result,result['name'],result['dataType'],result['value'].value))
 		
 def show(self,spaces = 0):
 	print ' ' * spaces + '-----------------------------------------------------------'
 	print ' ' * spaces + '%20s' % self.tagresult['fullPath']
 	print ' ' * spaces + '%20s' % 'Material Tag Properties'
 	self.properties.show(spaces + 3)
 		
class TagSnapshot():
 def __init__(self,tagpath):
 	self.tagpath = tagpath
 	self.init_ts = system.date.now()
	trace = 0
	self.materials = {}
	self.properties = KOPropertyList('TagSnapshot Segment Properties')
	pywrap = system.tag.browse( tagpath )
	results = pywrap.getResults()
	for result in results:
		if result['hasChildren'] == True and result['name'].upper() not in ['PRESET','PRESETS']:
			self.materials[result['name']] = KO.OpData.TagMaterial(result)

		elif result['hasChildren'] == False:
			self.properties.addProperty(KO.OpData.Property(result,result['name'],result['dataType'],result['value'].value))
			
 def show(self,spaces = 0):
	print ' ' * spaces + '---------------------------------------------------------------------------'
	print ' ' * spaces + 'tagpath: ' + self.tagpath
	print ' ' * spaces + 'TagMaterial Segment Properties------------------------------------'
	self.properties.show(spaces + 3)
	for m in self.materials.keys():
		self.materials[m].show(spaces + 3)
	print ' ' * spaces + '---------------------------------------------------------------------------snapshot'
					
def testTagSnapshot(tagname):
 	snap = KO.OpData.TagSnapshot(tagname)
 	snap.show(10)