import RossData
import time
def getStageData(job,stage):
	outputcharacteristics = {}
	testcodeResults = {}
	jobdata = RossData.getRossJobStageBoomi(item['JOB'],item['STAGE'])
	for each in jobdata['current_stage']['lines']['outputs']:
		for istic in each['characteristics']:
			outputcharacteristics[istic['name']] = istic['value']
	for testcode in each['test_codes']:
		testcodeResults[testcode['name']] = testcode['value_actual']
	return outputcharacteristics,testcodeResults

def buildFromERP(lot,materialName,locationName):
	import utils
	if not utils.checkForObject(lot,'MaterialLot'):
	
		lotdata = RossData.getRossLotInfoBoomi(lot)
		if 'HISTORY' not in lotdata.keys():
		
			try:
				# no history so this lot will magically appear
				castAlloy = lotdata['LOT']['CHEMISTRY']['ALLOY']
				qcStatus = lotdata['LOT']['CHEMISTRY']['QC_STATUS']
				partNo = lotdata['LOT']['MATERIAL']['AS_CAST_PART_CODE']
				length = lotdata['LOT']['MATERIAL']['AS_CAST_LENGTH']
				thickness = str(partNo[5:7])
				width = str(partNo[7:9])
				#print length,width,thickness,castAlloy,qcStatus,partNo
		
				#magicallyAppear


				locObj = system.mes.getMESObjectLinkByName('StorageUnit',locationName).getMESObject()
				seg = system.mes.createSegment('create purchased or unknown ingot','Kaiser\KAW\Admin\MES',0)
				seg.setMaterial('Material Out',materialName,locObj.equipmentPath,lot,1.0)
				seg = seg.begin()
				seg.setPropertyValue('castAlloy',str(castAlloy))
				seg.setPropertyValue('length',length)
				seg.setPropertyValue('width',width)
				seg.setPropertyValue('thickness',thickness)
				seg.setPropertyValue('reason','purchased ingot')
				seg = seg.update()
				seg.end()
				time.sleep(3)
				ml = system.mes.loadMaterialLot(lot,-1,0)
				ml.addCustomProperty('length','Float4','Length','in',1,1,length)
				ml.addCustomProperty('width','Float4','Width','in',1,1,width)
				ml.addCustomProperty('thickness','Float4','Thickness','in',1,1,thickness)
				ml.addCustomProperty('partNo','String','Part Number','text',1,1,partNo)
				ml.addCustomProperty('castAlloy','String','Alloy','text',1,1,castAlloy)
				ml.addCustomProperty('qcStatus','String','QC Status','text',1,1,qcStatus)
				system.mes.saveMESObject(ml)

				return 1
			except:
				return 0
				pass
		else:
			# this lot has erp history
			# stock convert from where it is
			return 1
	else:
		#material lot already in system
		return 0

def do():		
		import RossData
		import ROSS
		lot = '141733B6'
		ROSS.process.buildFromERP(lot,'ISAW1')
		lotdata = RossData.getRossLotInfoBoomi(lot)
		BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/lot/" + str(lot)
		jsonstr       = system.net.httpGet(BoomyEndpoint)
		system.file.writeFile('c:\Users/tr20131\localcache\%s.json' % lot,jsonstr)
		
		hist = lotdata['LOT']['HISTORY']
		for item in hist:
			print item['JOB'], item['STAGE']
			jobdata = RossData.getRossJobStageBoomi(item['JOB'],item['STAGE'])
			job = item['JOB']
			stage = item['STAGE']
			if item['STAGE'] == 'SR':
				BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/%s/%s" % (str(job),str(stage))
				jsonstr       = system.net.httpGet(BoomyEndpoint)
				system.file.writeFile('c:\Users/tr20131\localcache\%s.json' % job,jsonstr)
				for each in jobdata['current_stage']['lines']['outputs']:
					for istic in each['characteristics']:
						print istic
					for testcode in each['test_codes']:
						print testcode['name'], testcode['value_actual']
			och,tc = ROSS.process.getStageData(job,stage)
			print och
			print tc			