def getForEquipmentPeriod ( selectedName,startDate,endDate, databasename ):

	qrystr = """SELECT opr.OperationRefUUID,opr.BeginDateTime,opr.EndDateTime,eqp.Name,seg.Name as segName, seg.MESResponseSegmentUUID, opr.MESOperationsResponseUUID
FROM mesoperationsresponse opr,mesequipment eqp, mesresponsesegment seg
WHERE opr.Enabled = 1 and opr.EquipmentRefUUID = eqp.MESEquipmentUUID
and seg.OperationsResponseRefUUID = opr.MESOperationsResponseUUID
and eqp.Name like '%%%s%%'
and opr.EndDateTime < '%s' 
and opr.EndDateTime > '%s'
order by opr.EndDateTime desc""" % (selectedName,endDate,startDate)
	return system.db.runQuery(qrystr,databasename)