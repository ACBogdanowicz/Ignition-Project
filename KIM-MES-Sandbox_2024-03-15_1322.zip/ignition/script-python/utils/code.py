def getCharts():
	return system.sfc.getRunningCharts()
def getChartCount():
	return getCharts().rowCount
	
def getFilteredChartInstanceList(startingList,nameToFilterWith):
	charts = getCharts()				#get all running charts
	for i in range(charts.rowCount):	#for all rows in each chart
		row = []
		#for q in range(charts.columnCount):
			#print(charts.getValueAt(i,q))
		if nameToFilterWith in charts.getValueAt(i,1):
			logname = system.sfc.getVariables(charts.getValueAt(i,0))['logname']
			row.append(str(logname))
			row.append(charts.getValueAt(i,2))	#start datetime
			row.append(charts.getValueAt(i,0))	#instance ID
			startingList.append(row)
	orderedList = []
	for i in startingList:
		if 'Manager' in i[0]:
			orderedList.append(i)
	for i in startingList:
		if len(filter(str.isdigit,str(i[0]))) == 0 and 'Manager' not in i[0]:
			orderedList.append(i)

	kmax = 50	#for an sfc count up to 50... or 51 if we count 0.
	for k in range(kmax+1):	#add 1 for all ranges.
		for i in startingList:
			####compare each number in the range with the digits in the sfc log names to sort them.####
			#print(k,str(i[0]))
			if str(k) == filter(str.isdigit,str(i[0])):
				orderedList.append(i)	#append if we found one!
				break
	return orderedList	#return the list of [logname,start datetime,instanceID]
	
def getChildEquipmentNameArray(eqpath):
	result = []
	eqlnk = system.mes.getMESObjectLinkByEquipmentPath(eqpath)
	eqobj = eqlnk.getMESObject()
	#utils.pretty_dir(eqobj)
	childcol = eqobj.getChildCollection()
	for c in childcol:
		#print utils.pretty_dir(c)
		clnk = system.mes.getMESObjectLink(c)
		cobj = clnk.getMESObject()
		result.append(cobj.name)
	return result

def pretty_dir(obj, filter=""):
    results = [item for item in dir(obj) if filter in item.lower()]
    method_dict = {"get_methods": [],
        "set_methods": [],
        "is_methods": [],
        "add_methods": [],
        "remove_methods": []}
    for i in reversed(range(len(results))):
        if results[i].startswith('get'):
            method_dict["get_methods"].append(results.pop(i))
        elif results[i].startswith('set'):
            method_dict["set_methods"].append(results.pop(i))
        elif results[i].startswith('is'):
            method_dict["is_methods"].append(results.pop(i))
        elif results[i].startswith('add'):
            method_dict["add_methods"].append(results.pop(i))
        elif results[i].startswith('remove'):
            method_dict["remove_methods"].append(results.pop(i))
    for key, values in method_dict.iteritems():
        print key
        for item in values:
            print "    %s" % item
    print "others"
    for item in results:
        print "    %s" % item

def checkcheck():
	print ('checkcheck')
	    
def checkForObject(objName, objType):
	filter = system.mes.object.filter.createFilter()
	filter.setMESObjectTypeName(objType)
	filter.setMESObjectNamePattern(objName)
	linkList = system.mes.searchMESObjects(filter)
	return True if linkList.size() > 0 else False
	
def getLotTraceResultsDataset(lotNumber):
	import system
	log = system.util.getLogger("Lot Trace Results Report")
	log.info(lotNumber)
	 
	traceHeader = ["LotName", "ParentLotName", "LotStatus", "LotUse", "LotBeginDateTime", "LotEndDateTime", "LotQuantity", "MaterialName", "LotLocationName", "SegmentUUID", "SegmentName", "SegmentLocationName", "Depth"]
	traceData = utils.getLotTraceResults(lotNumber)
	return system.dataset.toDataSet(traceHeader, traceData)
	
def getLotTraceResults(lotNumber, usedLotNumbers=[], depth=0):
	import system
	 
	if depth == 0:
		usedLotNumbers = []
	 
	if lotNumber in usedLotNumbers:
		return []
	else:
		usedLotNumbers.append(lotNumber)
	 
	traceData = []
	subTraceData = []
	 
	results = system.dataset.toPyDataSet(system.mes.getLotTraceByLotName(lotNumber, "", 100, True))
	for row in results:
		lotUse = row["LotUse"]
		lotName = row["LotName"]
		 
		traceData.append([row["LotName"], lotNumber, row["LotStatus"], row["LotUse"], row["LotBeginDateTime"], row["LotEndDateTime"], row["LotQuantity"], row["MaterialName"], row["LotLocationName"], row["SegmentUUID"], row["SegmentName"], row["SegmentLocationName"], depth])
		 
		if lotUse == "In":
			traceData.extend(utils.getLotTraceResults(lotName, usedLotNumbers, depth+1))
		 
	return traceData	
	
def createRecipe(recipeName, eqPath):
	from org.apache.log4j import Logger
	log = Logger.getLogger('createRecipeScriptLogger')
	
	recipeExists = utils.checkForObject(recipeName, 'Recipe')
	
	if not recipeExists:
		# create the recipe
		parentRecipeName = ''
		note = 'Script-created recipe'
		system.recipe.createRecipe(recipeName, parentRecipeName, note)
		# assign production item to recipe
		system.recipe.addItemToRecipe(recipeName, eqPath, note)
		# display current recipe values
		category = '1' # indicates recipe values were created by the recipe module
		recipeVals = system.recipe.getRecipeValues(eqPath, recipeName, category)
		log.info('Original recipe values')
		log.info('--------------------------------')
		for ndx in range(recipeVals.size()):
			recipeItem = recipeVals.get(ndx) # get the recipe value item object #recipeItem = recipeVals.get(ndx).getRecipeValue() # if used in gateway scope
			itemName = recipeItem.getName()
			itemValue = str(recipeItem.getValue())
			#itemSort = recipeItem.getSortOrder()
			#recipeItem.getMinValue()
			#recipeItem.getMaxValue()
			#recipeItem.getAssignedBy()
			#recipeItem.getSortOrder()
			#recipeItem.hasDescription()
			#recipeItem.getDescription()
			#recipeItem.getFormat()
			#recipeItem.getUnits()
			log.info('%s=%s' % (itemName, itemValue))
		# assign values to the recipes items
		valueName = 'Torque Setting 1'
		value = '3.0' # always assign as a string, the module will convert to the proper type
		note = 'value changed'
		system.recipe.setPathRecipeValue(eqPath, recipeName, valueName, value, note)
		valueName = 'Zero Location'
		value = '7.5'
		note = 'value changed'
		system.recipe.setPathRecipeValue(eqPath, recipeName, valueName, value, note)
		# display new values
		recipeVals = system.recipe.getRecipeValues(eqPath, recipeName, category)
		log.info(' ')
		log.info('Modified recipe values')
		log.info('--------------------------------')
		for ndx in range(recipeVals.size()):
			recipeItem = recipeVals.get(ndx)
			itemName = recipeItem.getName()
			itemValue = str(recipeItem.getValue())
			log.info('%s=%s' %(itemName, itemValue))
		return True
	else:
		return False
		
##Create an Operations Definition and Operations Segment based on a Process Segment
##Notice that this is the simple case - 1 Process Segment per Operations Definition / Operations Segment.
		 
def createOperations(psName):
	val = False
	if not utils.checkForObject(psName, 'OperationsSegment'):
		     
		        ps = system.mes.loadMESObject(psName, 'ProcessSegment')
		              
		        #Derive a new operation segment from the process segment
		        os = system.mes.deriveMESObject(ps, 'OperationsSegment', True)
		              
		        #Set where it was derived from
		        os.setPropertyValue('DerivedFromRefType', 'ProcessSegment')
		        os.setPropertyValue('DerivedFromRefUUID', ps.getUUID())
		              
		        #Set the name
		        os.setPropertyValue('Name', psName)
		                 
		        #Create a new operations definition
		        od = system.mes.createMESObject('OperationsDefinition')
		        #Set the name using the same name as the operations segment
		        od.setPropertyValue('Name', psName)
		              
		        #Create a new segment dependency complex property in the operations definition that points to the operations segment
		        depProp = od.createComplexProperty('SegmentDependency', ps.getName())
		        depProp.setSegmentRefType('OperationsSegment')
		        depProp.setSegmentRefUUID(os.getUUID())
		              
		        #Create a new begin trigger complex property in the operation segment
		        begTrig = os.createComplexProperty('TriggerSegBegin', 'DefaultBeginTrigger')
		        begTrig.setPrecedingRefType('OperationsDefinition')
		        begTrig.setPrecedingRefUUID(od.getUUID())
		        begTrig.setMode('At Operation Begin')
		        begTrig.setDefault(True)
		              
		        #Save the objects as a group
		        objList = system.mes.object.list.createList()
		        objList.add(od)
		        objList.add(os)
		        system.mes.saveMESObjects(objList)
		        val = True
		     
	return val
	
def checkIfLotExistsByCustProp(custPropName, custPropVal):
	    #This function is passed a custom property name and value and returns a count of matching lots
	    #This can be used to determine if a material lot had already been entered
	 
	    # example:  custPropName = 'CoilNumber'
	    #           custPropVal = '01150007715408'
	    #           print checkIfLotExistsBYCustProp(custPropName, custPropVal)
	            
	    if custPropVal is not None and custPropVal != "" and custPropName is not None and custPropName != "":
	        filter = system.mes.object.filter.createFilter()
	        list = system.mes.object.filter.parseCustomPropertyValueFilter(custPropName + " = " + custPropVal)
	        filter.setCustomPropertyValueFilter(list)
	        filter.setEnableStateName('ENABLED')
	        filter.setMESObjectTypeName('MaterialLot')
	        objs = system.mes.loadMESObjects(filter)
	        retVal = objs.size()
	    else:
	        retVal = -1
	 
	    #print "coilNumber - %s, retVal %s", str(coilNumber),str(retVal)
	 
	    return retVal