
import SlabTracking
import Wagon
next = 0

tagresults = system.tag.readBlocking(['[MES_Tags]Kaiser/KAW/Hot Rolling/Slab Tracking/mes/BaseLot_Reporting/Material In/Lot',
		'[MES_Tags]Kaiser/KAW/Hot Rolling/Slab Tracking/mes/BaseLot_Reporting/finalMill',
		'[MES_Tags]Kaiser/KAW/Hot Rolling/Slab Tracking/mes/BaseLot_Reporting/fullCount',
		'[MES_Tags]Kaiser/KAW/Hot Rolling/Slab Tracking/mes/BaseLot_Reporting/multipleCount',
		'[MES_Tags]Kaiser/KAW/Hot Rolling/Slab Tracking/mes/BaseLot_Reporting/wagonOrTray'])
for each in tagresults:
		print each
		
baselot = tagresults[0].value
ml = system.mes.loadMaterialLot(baselot,-1,0)
print ml.name
print ml.getLotInventory().getNetQuantity()
qty = ml.getLocationLink().getMESObject()
if qty == 0.0:
	print 'parent has no quantity'
	ml = system.mes.loadMaterialLot(baselot + '-1',-1,0)
	print ml.name
	cqty = ml.getLotInventory().getNetQuantity()
	print cqty
	print ml.getLocationLink().getMESObject()
		
slabs = SlabTracking.Inventory.findBaseLotResults2(tagresults[0].value)
print slabs

if next:
 if len(slabs) > 0:
	print 'slabs:'
	for slab in slabs:
			print slab.getName()
	wagonId = 'Wagon %d' % int(str(tagresults[4].value).strip())
	print wagonId
	if not utils.checkForObject(wagonId,'Equipment'):
		print 'no such wagon'
	else:
		print 'wagon found'
		
		wagcontent,age = Wagon.getContentWithAge(wagonId)
		print wagcontent
		print age
		#SlabTracking.ITS.baseLotWagonTransfer(wagonId,slabs)

 else:
	print 'no slabs'
