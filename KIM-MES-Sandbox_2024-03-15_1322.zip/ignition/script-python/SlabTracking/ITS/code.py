def emptyWagon(wagonid,reason):
	import time
	wagobj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
	nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)

	for nl in nextlots:
		ml = system.mes.loadMaterialLot(str(nl),-1,0)
		seg = system.mes.createSegment('scrapWagonPlate','Kaiser\KAW\Admin\Handling',True)
		seg.setSupplementalEquipment('wagon',wagobj.name)
		seg.setPropertyValue('reason',reason)
		seg.setMaterial('Material In',ml.name)
		seg.execute()
		
	time.sleep(20)
	
def baseLotWagonTransfer(wagonid,slabs,tagarray):
	import time
	wagObj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	lotnames = []
	duplotnames = []
	eqpath = 'Kaiser\KAW\Hot Rolling\ITS'
	nextlots = slabs
	propdict = {}
	seg = system.mes.createSegment('autoDEQUEUE_ITS',eqpath,True)
	if len(tagarray) > 0:
		seg.setPropertyValue('wagonId',tagarray[4].value)
		seg.setPropertyValue('finalMill',tagarray[1].value)
		seg.setPropertyValue('fullCount',int(tagarray[2].value))
		seg.setPropertyValue('multipleCount',int(tagarray[3].value))
	print 'fetching ordered queue content'
	print seg
	logger = system.util.getLogger('MES_ITS')
	seg.setSupplementalEquipment('wagon',wagObj.name,{})
	#nextlots = queueseg.getAvailableMaterialLots('Material In',eqpath)
	props = {}
	itemno = 1

	if len(slabs) > 0:
		for ml in slabs:
			lotname = ml.name
			if ml.name not in lotnames:
				lotnames.append(ml.name)
			else:
				duplotnames = []
				lotname = ml.name + '_dup'
				
			time.sleep(2)
			
			qty = ml.getLotInventory().getNetQuantity()
			seg.setMaterial('Material In %02d' % itemno,lotname)
		
			propdict = {}
			custprops = ml.getAllCustomProperties()
			for cp in custprops:
				print ( cp )
				if cp.name not in ['EquipmentName','LastOp']:
					propdict[cp.name] = [str(cp.getIgnitionDataType()),cp.value,cp.getDescription(),cp.getUnits()]
					logger.info(cp.name)
					logger.info(str(cp.getIgnitionDataType()))
					
			print propdict

			props[itemno] = propdict
		
			#seg.setMaterial('Material Out %02d' % itemno,ml.getMaterialDefLink().name,wagonid,inlot.name,qty,propdict)
			seg.setMaterial('Material Out %02d' % itemno,'Plate',wagObj.name,lotname,qty,propdict)
			itemno = itemno + 1
		seg = seg.begin()
		try:
	 		#seg.execute()
	 		itemno = itemno - 1
	 		if len(nextlots) > 0:
				while itemno > 0:
					#for inlot in nextlots:
					#ml = system.loadMaterialLot(inlot.name,-1,0,0)
					ml = seg.getMaterial('Material Out %02d' % itemno)
					print ml.name
					for itemkey in props[itemno].keys():
						ml.setPropertyValue(itemkey,props[itemno][itemkey].value)
					#system.saveMESObject(ml)
					itemno = itemno - 1
	 		seg = seg.update()
		except:
			print 'exception in property transfer %s %d' % ( ml.name, itemno )
			pass
	
		seg.end()
		
def baseLotWagonTransfer2(wagonid,slabs,tagarray):
	import time
	wagObj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	lotnames = []
	duplotnames = []
	eqpath = 'Kaiser\KAW\Hot Rolling\ITS'
	nextlots = slabs
	propdict = {}
	#seg = system.mes.createSegment('autoDEQUEUE_ITS',eqpath,True)
	#if len(tagarray) > 0:
	#	seg.setPropertyValue('wagonId',tagarray[4].value)
	#	seg.setPropertyValue('finalMill',tagarray[1].value)
	#	seg.setPropertyValue('fullCount',int(tagarray[2].value))
	#	seg.setPropertyValue('multipleCount',int(tagarray[3].value))
	finalMill = tagarray[1].value

	logger = system.util.getLogger('MES_ITS_wagonxfer')
	logger.warn('executing baseLotWagonTransfer2')
	#seg.setSupplementalEquipment('wagon',wagObj.name,{})
	#nextlots = queueseg.getAvailableMaterialLots('Material In',eqpath)
	props = {}
	for ml in slabs:
		logger.warn(ml.name)
		
	if len(slabs) > 0:
		for ea in slabs:
			ml = system.mes.loadMaterialLot(ea.getName(),-1,0)
			logger.warn('first slab %s' % ml.name)
			seg = system.mes.createSegment('dequeuePlate_ITS',eqpath,True)
			if len(tagarray) > 0:
				seg.setPropertyValue('wagonId',tagarray[4].value)
				seg.setPropertyValue('finalMill',tagarray[1].value)
				seg.setPropertyValue('fullCount',int(tagarray[2].value))
				seg.setPropertyValue('multipleCount',int(tagarray[3].value))
			seg.setSupplementalEquipment('wagon',wagObj.name,{})
			lotname = ml.name
			if ml.name not in lotnames:
				lotnames.append(ml.name)
			else:
				duplotnames = []
				lotname = ml.name + '_dup'
						
			time.sleep(2)
					
			qty = ml.getLotInventory().getNetQuantity()
			seg.setMaterial('Material In',lotname)
				
			propdict = {}
			custprops = ml.getAllCustomProperties()
			for cp in custprops:
				#print ( cp )
				if cp.name not in ['EquipmentName','LastOp']:
					propdict[cp.name] = [str(cp.getIgnitionDataType()),cp.value,cp.getDescription(),cp.getUnits()]
					logger.info(cp.name)
					logger.info(str(cp.getIgnitionDataType()))
							
			#print propdict
				
			#seg.setMaterial('Material Out %02d' % itemno,ml.getMaterialDefLink().name,wagonid,inlot.name,qty,propdict)
			seg.setMaterial('Material Out','Plate',wagObj.name,lotname,qty,propdict)

			seg = seg.begin()
			try:
				ml = seg.getMaterial('Material Out')
				#print ml.name
				for itemkey in propdict.keys():
					ml.setPropertyValue(itemkey,propdict[itemkey].value)
				#system.saveMESObject(ml)
				seg = seg.update()
			except:
				logger.warn( 'exception in property transfer %s' % ( ml.name ) )
				pass
			
			seg.end()
			
def baseLotReport(slabs,tagarray):
	import time
	lotnames = []
	duplotnames = []
	eqpath = 'Kaiser\KAW\Hot Rolling\ITS'
	nextlots = slabs
	propdict = {}
	finalMill = 'X'
	seg = system.mes.createSegment('autoDEQUEUE_ITS',eqpath,True)
	if len(tagarray) > 0:
		seg.setPropertyValue('wagonId',tagarray[4].value)
		seg.setPropertyValue('finalMill',tagarray[1].value)
		seg.setPropertyValue('fullCount',int(tagarray[2].value))
		seg.setPropertyValue('multipleCount',int(tagarray[3].value))
		finalMill = tagarray[1].value
	#print 'fetching ordered queue content'
	#print seg
	logger = system.util.getLogger('MES_ITS')
	#nextlots = queueseg.getAvailableMaterialLots('Material In',eqpath)
	props = {}
	qtysum = 0
	platelengths = []
	itemno = 1
			
	if len(slabs) > 0:
		for ml in slabs:
			lotname = ml.name
			logger.info(lotname)
			if ml.name not in lotnames:
				lotnames.append(ml.name)
			else:
				duplotnames = []
				lotname = ml.name + '_dup'
							
			time.sleep(2)
						
			qty = ml.getLotInventory().getNetQuantity()
			qtysum = qtysum + qty
			platelengths.append(ml.getPropertyValue('Length'))
			seg.setMaterial('Material In %02d' % itemno,lotname)
					
			propdict = {}
			custprops = ml.getAllCustomProperties()
			for cp in custprops:
				#print ( cp )
				if cp.name not in ['EquipmentName','LastOp']:
					propdict[cp.name] = [str(cp.getIgnitionDataType()),cp.value,cp.getDescription(),cp.getUnits()]
					logger.info(cp.name)
					logger.info(str(cp.getIgnitionDataType()))
								
			#print propdict
			
			props[lotname] = propdict
					
			#seg.setMaterial('Material Out %02d' % itemno,ml.getMaterialDefLink().name,wagonid,inlot.name,qty,propdict)
			seg.setMaterial('Material Out %02d' % itemno,'Slab','Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking',lotname,qty,propdict)
			itemno = itemno + 1
		seg.setPropertyValue('trackingTotalWeight',qtysum)
		seg.setPropertyValue('trackingFullCount',len(platelengths))
		seg = seg.begin()
		try:
			#seg.execute()
			itemno = itemno - 1
			if len(nextlots) > 0:
				while itemno > 0:
					#for inlot in nextlots:
					#ml = system.loadMaterialLot(inlot.name,-1,0,0)
					ml = seg.getMaterial('Material Out %02d' % itemno)
					#print ml.name
					for itemkey in props[itemno].keys():
						ml.setPropertyValue(itemkey,props[itemno][itemkey].value)
					#system.saveMESObject(ml)
					itemno = itemno - 1
			seg = seg.update()
		except:
			#print 'exception in property transfer %s %d' % ( ml.name, itemno )
			logger.info( 'exception in property transfer %s %d' % ( ml.name, itemno ))

			pass
				

		seg.end()

	skip = """	
	if len(slabs) > 0:
		for ml in slabs:
			lotname = ml.name
			lotseq = ml.getLotSequence()
			SlabTracking.copyStuff.do(lotname,lotseq,lotname,-1)
	
			if ml.name not in lotnames:
				lotnames.append(ml.name)
			else:
				duplotnames = []
				lotname = ml.name + '_dup'
			
			nml = system.mes.loadMaterialLot(lotname,-1,0)
			custprops = ml.getAllCustomProperties()
			for cp in custprops:
				print ( cp )
				if cp.name not in ['EquipmentName']:
					nml.addCustomProperty(cp.name,str(cp.getIgnitionDataType()),cp.getDescription(),cp.getUnits(),1,1)
					nml.setPropertyValue(cp.name,cp.value)
			
			system.mes.saveMESObject(nml)
	"""

				