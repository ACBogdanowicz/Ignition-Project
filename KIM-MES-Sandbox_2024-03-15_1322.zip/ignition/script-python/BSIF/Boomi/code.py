import system
def getRossSchedInfoBoomi(Stage, Date):
                import system
                joblist  = []
                schedret = {}
                
                datestr       = system.date.format(Date,'YYYYMMdd')
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/schedule/?Date=%s&Stage=%s" % (datestr, str(Stage))
                #print BoomyEndpoint
                jsonstr   = system.net.httpGet(BoomyEndpoint)
                scheddata = system.util.jsonDecode(jsonstr)
                for bjob in scheddata['schedule']['jobs']:
                                schedret[bjob['Job_number']] = {}
                                schedret[bjob['Job_number']]['actual_machine']    = bjob['actual_machine']
                                schedret[bjob['Job_number']]['actual_start_date'] = bjob['actual_start_date']
                                schedret[bjob['Job_number']]['batch_id']          = bjob['batch_id']
                                schedret[bjob['Job_number']]['planned_machine']   = bjob['planned_machine']
                                schedret[bjob['Job_number']]['process_stage']     = bjob['process_stage']
                                schedret[bjob['Job_number']]['schedule_es_date']  = bjob['schedule_es_date']
                                #lotdata[blot['LOT_NUMBER']]['STATUS']=blot['STATUS']
                #print stages
                return schedret

def getRossBinInfoBoomi(bin):
                lotlist = []
                lotdata = {}
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/bin?Bin=" + str(bin)
                #print BoomyEndpoint
                jsonstr = system.net.httpGet(BoomyEndpoint)
                bindata = system.util.jsonDecode(jsonstr)
                for blot in bindata['BIN']['DETAIL']:
                                lotdata[blot['LOT_NUMBER']]              = {}
                                lotdata[blot['LOT_NUMBER']]['PART_CODE'] = blot['PART_CODE']
                                lotdata[blot['LOT_NUMBER']]['STATUS']    = blot['STATUS']
                #print stages
                return lotdata    

def getRossLotInfoBoomi(Lot):
                stagelist     = []
                lotdata       = {}
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/lot/" + str(Lot)
                #BoomyEndpoint = "http://frpbmtest.kaiseraluminum.com/ws/rest/erp/lot/?Lot=" + str(Lot)
                #print BoomyEndpoint
                jsonstr       = system.net.httpGet(BoomyEndpoint)
                lotdata       = system.util.jsonDecode(jsonstr)
                return lotdata

def getRossJobStagesBoomi(job):
                #import pprint
                stagelist     = []
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/" + str(job)
                jsonstr       = system.net.httpGet(BoomyEndpoint)
                jobdict       = system.util.jsonDecode(jsonstr)
                #pprint.pprint(jobdict['stages'])
                for stagedict in jobdict['stages']:
                                stagelist.append(stagedict['name'])
                #print stages
                return stagelist

def getRossCurrStageBoomi(job):
                #import pprint
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/" + str(job)
                jsonstr       = system.net.httpGet(BoomyEndpoint)
                jobdict       = system.util.jsonDecode(jsonstr)
                #print stages
                return jobdict['current_stage']

def getRossJobStageBoomi(job, stage):
                #import pprint
                BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/%s/%s" % (str(job),str(stage))
                jsonstr       = system.net.httpGet(BoomyEndpoint)
                jobdict       = system.util.jsonDecode(jsonstr)
                #print stages
                return jobdict