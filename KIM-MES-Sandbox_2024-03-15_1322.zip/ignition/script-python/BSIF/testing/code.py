def do():
	import BSIF
	lot = '448900B1'
	print '---'
	print BSIF.Extractors.getThermalCodeForLot(lot)
	print BSIF.Extractors.getBatchCodeForLot(lot)
	print BSIF.Extractors.getWagonLotSummary(lot)
	print '---'