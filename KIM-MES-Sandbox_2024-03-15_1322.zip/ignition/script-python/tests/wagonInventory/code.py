def do():
	import Wagon
	uw = []
	wagclass = system.mes.getMESObjectLinkByName('EquipmentClass','Wagons').getMESObject()
	wagons = wagclass.getChildCollection()
	coll = []
	cont = []
	for wag in wagons:
		wagObj = system.mes.loadMESObject(wag)
		if wagObj.name not in uw:
			uw.append(wagObj.name)
			print '>' + wagObj.name + '<'
		else:
			print '>>' + wagObj.name + '<<'
		if wagObj.name not in coll:
			coll.append(wagObj.name)
		else:
			print wagObj.name
		l,wc,ag = Wagon.getContentWithAge2(wagObj)
		if len(wc) > 0:
			cont.append(wagObj.name)
			print ag,len(wc),len(l),l
	print len(coll)
	print len(cont)

def checkDatabase():
	pyds = system.db.runQuery("SELECT MESEquipmentUUID,name,enabled FROM MESEquipment where name like 'Wagon%'")
	for row in pyds:
		if row[2] == 1:
			w,n = row[1].split(' ')
			try:
				wagno = int(n)
			except:
				print row[0]
				print '>' + row[1] + '<',str(len(row[1]))
				print row[2]
				raise