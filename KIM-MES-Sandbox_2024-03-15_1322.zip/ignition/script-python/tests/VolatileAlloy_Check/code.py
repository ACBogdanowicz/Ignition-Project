import system

#K75x, K21x, 7x75 >= 235, 7017, K791, K777
#kop : made to be work based on the basepath of the SFC so that the generic Casting_SFC can call check()
#http://docsrv/practice/practice/metprac/m095102.htm
#Refer to link above for official conditiosn on sending ingots to stress relief / reheat.


def writeMaterialName(basepath,volatile):	#(path to pit tags, volatile flag used to set material type)
	path = basepath + '/CAST/Material Out '
	for j in range(1,7):	#for all mold positions
		if volatile:
			print (path + "%d/MaterialName" %j,'Volatile Ingot')
			#system.tag.write(path + "%d/MaterialName" %j,'Volatile Ingot')
		else:
			print (path + "%d/MaterialName" %j,'Ingot')
			#system.tag.write(path + "%d/MaterialName" %j,'Ingot')

def check(basepath,i):	#(path to pit tags, station number)
	alloy   =   str(system.tag.read(basepath + '/CAST/castAlloy'      ).value)
	length  = round(system.tag.read(basepath + '/CAST/lengthActual'   ).value,1)
	targlen = round(system.tag.read(basepath + '/CAST/lengthScheduled').value,1)
	if (alloy[0] == '7' and alloy[2:] == '75' or alloy == 'K771' or alloy == 'k771') and length >= 235 or alloy == '7017':
			writeMaterialName(basepath,True)
	elif alloy[0] == 'K' or alloy[0] == 'k':
		if (alloy[1] == '7' and alloy[2] == '5') or (alloy[1] == '2' and alloy[2] == '1') or alloy[1:] == '791' or alloy[1:] == '777':
			print 'Station %d'%i, alloy, length, 'volatile!'
			writeMaterialName(basepath,True)
		else:
			writeMaterialName(basepath,False)
	elif alloy == '2024':
		if length > targlen + 1:
			writeMaterialName(basepath,True)
		else:
			writeMaterialName(basepath,False)
	else:
		print 'Station %d'%i, alloy, length
		writeMaterialName(basepath,False)
			
def checkAll():
	for i in range(0,9):	#stations 0 to 8
		path = "[MES_Tags]Kaiser/KAW/Casting/DC%d/DC%d-Pit/mes" % (i,i)
		check(path,i)

			