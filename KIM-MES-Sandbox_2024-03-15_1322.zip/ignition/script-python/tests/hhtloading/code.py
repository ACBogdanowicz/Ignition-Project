def do():
 import utils
 import SlabTracking
 nlot = system.tag.readBlocking([	'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/North/Lot',
									'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/North/PIECE'])
 slot = system.tag.readBlocking([	'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/South/Lot',
									'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/South/PIECE'])
 clot = system.tag.readBlocking([	'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/Center/Lot',
									'[MES_Tags]Kaiser/KAW/Plate Flow/HHT1/mes/HTStage/Center/PIECE'])
 print 'n',nlot[0].value,nlot[1].value
 print 's',slot[0].value,slot[1].value
 print 'c',clot[0].value,clot[1].value
 lotexists = 0
 lot = nlot[0].value
 if lot == '':
	print 'no lot found'
	lotexists = 0
 else:
	lot = nlot[0].value +'-' + str(nlot[1].value)
	print 'searching for ',lot
	if utils.checkForObject(lot,'MaterialLot'):
		lotexists = 1
	print utils.checkForObject(lot,'MaterialLot')
	if not lotexists:
		print 'searching for ',nlot[0].value
		if utils.checkForObject(nlot[0].value,'MaterialLot'):
			lotexists = 1
		print utils.checkForObject(nlot[0].value,'MaterialLot')
		lot = nlot[0].value
		
 master = ''
 if lotexists:
	if lot.find('-') > 0:
		flds = lot.split('-')
		master = flds[0]
	else:
		master = lot
	print lot 
	ml = system.mes.loadMaterialLot(lot,-1,0)
	qty = ml.getLotInventory().getNetQuantity()
	print qty
	locObj = ml.getLocationLink().getMESObject()
	print locObj.name
	if locObj.name == 'Slab Tracking':
		slabs = SlabTracking.Inventory.findBaseLotResults3(nlot[0].value)
		# convert first slab to plate
		if ml in slabs:
			skip="""
			seg = system.mes.createSegment('wagonBypass','Kaiser\KAW\Admin\Handling')
			seg.setMaterial('Material In',lot)
			seg.setMaterial('Material Out',Plate','Kaiser\KAW\Plate Flow\HHT1\HHT1Staging\HHT1StagingNorth',lot,qty)
			seg.execute()
			"""
			print 'execute wagonBypass'
		for s in slabs:
			print s.name
		print len(slabs)
	if locObj.name[0:5] == 'Wagon':
		# find top piece of lot on wagon
		print 'wagon'
		seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
		print locObj.name
		nextlots = seg.getAvailableMaterialLots('Material In',locObj.name)
		for l in nextlots:

			if (l.name).find('-') > 0:
				flds = (l.name).split('-')
				lm = flds[0]
			else:
				lm = l
			
			if lm == master:	
				print '+',l
			else:
				print 'x',l
 else:
	print 'lot %s does not exist' % lot
