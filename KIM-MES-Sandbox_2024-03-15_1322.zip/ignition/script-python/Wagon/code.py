import system
import utils

def OneLineContentDescription(wagonId):
	wobj = Wagon.getWagonObject(wagonId)
	#wobj = system.mes.getMESObjectLinkByName('Equipment',wagonId).getMESObject()
	result = []
	seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)

	result.append(wobj.name)
	nl = None
	nextlots = seg.getAvailableMaterialLots('Material In',wobj.name)
	lots = []
	pieces = []
	hprac = []
	bprac = []
	gauge = []
	width = []
	parts = []
	bl = ''
	el = ''
	for nl in nextlots:
	 try:
		if str(nl).find('-') > 0:
			bl,el = str(nl).split('-')
		else:
			bl = nl
		if bl not in lots:
			lots.append(bl)
			if utils.checkForObject(bl,'MaterialLot'):
				ml = system.mes.loadMaterialLot(bl,-1,0)
			
				pieces.append(1)
				gauge.append(float(ml.getPropertyValue('Thickness')))
				width.append(float(ml.getPropertyValue('Width')))
				hp = bp = '??'
				try:
					mlhp = ml.getPropertyValue('HT_Practice')
					if mlhp != None:
						hp = mlhp
				except:
					hp = '??'
					pass
				try:
					mlbp = ml.getPropertyValue('Batch_Practice')
					if mlbp != None:
						bp = mlbp
				except:
					bp = '??'
					pass
					
				hprac.append(hp)
				bprac.append(bp)
			else:
				pieces.append(1)
				gauge.append(0.0)
				width.append(0.0)
				hprac.append('xx')
				bprac.append('xx')
		else:
			if lots[-1] == bl:
				pieces[-1] = pieces[-1] + 1
	 except:
	 	pass
	
	rstr = ''
	for i in range(0,len(lots)):
		rstr = rstr + lots[i] + ' _' + str(pieces[i]) + '_ %4.2F' % gauge[i] + ' %2.1F' % width[i] + ' ' + hprac[i] + ' ' + bprac[i] + ' : '
	result.append(rstr)
	return result
	
def PopulateTableWithInventoryLocation(locationPath,tableObj):
	seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
	nextlots = seg.getAvailableMaterialLots('Material In',locationPath)
	
	tableObj.data = system.dataset.clearDataset(tableObj.data)
	cnt = 0
	if len(nextlots) > 0:
		dataset = tableObj.data
		headers = ['Lot','Status']
		data = []
		ml = system.mes.loadMaterialLot(str(nextlots[0]),-1,0)
		data.append([nextlots[0],ml.getPropertyValue('LotStatus')])
		tableObj.data = system.dataset.toDataSet(headers,data)
		cnt = 1
				
	i = 0
	for nl in nextlots:
		if i >= 1:
			ml = system.mes.loadMaterialLot(str(nl),-1,0)
			tableObj.data = system.dataset.addRow(tableObj.data,[nl,ml.getPropertyValue('LotStatus')])
			cnt = cnt + 1
		i = i + 1
	return cnt
		
def PopulateTableWithWagonErr(wagonid,tableObj):
	wagobj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	seg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
	op = system.mes.getCurrentOperation('Kaiser\KAW\Admin\Handling')
	if op != None:
		op.abort()
	seg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
	matprop = seg.getMaterialProperty('Material In')
	print matprop.name
	seg.begin()
	nextlots = system.mes.getMaterialLotsAvailable(matprop,100, '', wagonid)
	#nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)
	
	tableObj.data = system.dataset.clearDataset(tableObj.data)
	cnt = 0
	for mlnk in nextlots:
		ml = mlnk.getMESObject()
		if cnt == 0:
			dataset = tableObj.data
			headers = ['Lot','Status']
			data = []
			#ml = system.mes.loadMaterialLot(nextlots[0].getLotNumber,-1,0)
			data.append([ml.name,''])
			tableObj.data = system.dataset.toDataSet(headers,data)
		if cnt > 0:
			tableObj.data = system.dataset.addRow(tableObj.data,[ml.name,''])
		cnt = cnt + 1
	
	seg.abort()
	return cnt
	
def PopulateTableWithWagon(wagonid,tableObj):
		wagobj = Wagon.getWagonObject(wagonid)
		#wagobj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
		seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
		nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)
		
		tableObj.data = system.dataset.clearDataset(tableObj.data)
		cnt = 0
		if len(nextlots) > 0:
			dataset = tableObj.data
			headers = ['Lot','Status']
			data = []
			ml = system.mes.loadMaterialLot(str(nextlots[0]),-1,0)
			data.append([nextlots[0],ml.getPropertyValue('LotStatus')])
			tableObj.data = system.dataset.toDataSet(headers,data)
			cnt = 1
					
		i = 0
		for nl in nextlots:
			if i >= 1:
				ml = system.mes.loadMaterialLot(str(nl),-1,0)
				tableObj.data = system.dataset.addRow(tableObj.data,[nl,ml.getPropertyValue('LotStatus')])
				cnt = cnt + 1
			i = i + 1
		return cnt

def test(wagonid):
	tableOn = 0
	wagobj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	obj = system.mes.loadMESObject('wagonCheck','OperationsSegment')
	seg = system.mes.createSegment(obj,'Kaiser\KAW\Admin\Handling',True)
	matprop = seg.getMaterialProperty('Material In')
	nextlots = system.mes.getMaterialLotsAvailable(matprop,100,'',wagonid)
	print nextlots
	for nl in nextlots:
		print '---'
		print (nl)

	if tableOn: tableObj.data = system.dataset.clearDataset(tableObj.data)
	cnt = 0
	if len(nextlots) > 0:
		if tableOn:
			dataset = tableObj.data
			headers = ['Lot','Status']
			data = []
		ml = system.mes.loadMaterialLot(str(nextlots[0]),-1,0)
		if tableOn:
			data.append([nextlots[0],ml.getPropertyValue('LotStatus')])
		else:
			print ml.name
		if tableOn: tableObj.data = system.dataset.toDataSet(headers,data)
		cnt = 1
			
	i = 0
	for nl in nextlots:
		if i >= 1:
			ml = system.mes.loadMaterialLot(str(nl),-1,0)
			if tableOn:
				tableObj.data = system.dataset.addRow(tableObj.data,[nl,ml.getPropertyValue('LotStatus')])
			else:
				print ml.name
			cnt = cnt + 1
		i = i + 1
	return cnt
	
def getContent(wagonid):
	wagobj = Wagon.getWagonObject(wagonid)
	#wagobj = system.mes.getMESObjectLinkByName('Equipment',str(wagonid)).getMESObject()
	seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
	nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)
	content = []

	for nl in nextlots:
			ml = system.mes.loadMaterialLot(str(nl),-1,0)
			content.append(ml)

	return content

def getWagonObject(wagonid):

	try:
		pds = system.db.runQuery("SELECT MESEquipmentUUID,Name FROM MESEquipment where Name like '%s%%'" % wagonid,'MES_Analysis')
		system.db.runQuery
		wguuid = None
		if pds.getRowCount() > 1:
			for row in pds:
				if row[1].strip() == wagonid:
					waguuid = row[0]
					break
		else:
			waguuid = pds[0][0]
		wagobj = system.mes.loadMESObject(waguuid)
	except:
		wagobj = system.mes.getMESObjectLinkByName('Equipment',str(wagonid)).getMESObject()
		
	wagobj = system.mes.getMESObjectLinkByName('Equipment',str(wagonid)).getMESObject()
	return wagobj
	
def getContentWithAge(wagonid):
		wagobj = getWagonObject(wagonid)
		seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
		nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)
		content = []
		now = system.date.now()
		lastdate = now
		age = 1000
	
		for nl in nextlots:
				ml = system.mes.loadMaterialLot(str(nl),-1,0)
				content.append(ml)
		if len(content) > 0:
			respuuid = content[0].getPropertyValue('ResponseSegmentUUID')
			print respuuid
			resp = system.mes.loadMESObject(respuuid)
			lastdate = resp.getPropertyValue('EndDateTime')
			age = system.date.hoursBetween(lastdate,now)
	
		return content,age
		
def getContentWithAge2(wagobj):
				lc = 0
				ulots = []
				seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
				nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)
				content = []
				now = system.date.now()
				lastdate = now
				age = 1000
			
				for nl in nextlots:
					if str(nl)[0:8] not in ulots:
						ulots.append(str(nl)[0:8])
					ml = system.mes.loadMaterialLot(str(nl),-1,0)
					content.append(ml)
				if len(content) > 0:
					respuuid = content[0].getPropertyValue('ResponseSegmentUUID')
					#print respuuid
					resp = system.mes.loadMESObject(respuuid)
					lastdate = resp.getPropertyValue('EndDateTime')
					age = system.date.hoursBetween(lastdate,now)
			
				return ulots,content,age
				
def emptyAllWagons():
	wagclass = system.mes.getMESObjectLinkByName('EquipmentClass','Wagons').getMESObject()
	wagons = wagclass.getChildCollection()
	for wag in wagons:
			wagObj = system.mes.loadMESObject(wag)
			emptyWagon(wagObj)
			
def emptyWagon(wagobj):
	seg = system.mes.createSegment('moveWagonPlate','Kaiser\KAW\Admin\Handling',True)
	nextlots = seg.getAvailableMaterialLots('Material In',wagobj.name)

	for nl in nextlots:
		ml = system.mes.loadMaterialLot(str(nl),-1,0)
		seg = system.mes.createSegment('scrapWagonPlate','Kaiser\KAW\Admin\Handling',True)
		seg.setSupplementalEquipment('wagon',wagobj.name)
		seg.setMaterial('Material In',ml.name)
		seg.execute()
	
def do(wagonid):
	tableOn = 0
	wagobj = system.mes.getMESObjectLinkByName('Equipment',wagonid).getMESObject()
	obj = system.mes.loadMESObject('wagonCheck','OperationsSegment')
	seg = system.mes.createSegment(obj,'Kaiser\KAW\Admin\Handling',True)
	matprop = seg.getMaterialProperty('Material In')
	nextlots = system.mes.getMaterialLotsAvailable(matprop,100,'',wagonid)
	print nextlots
	for nl in nextlots:
		print nl.getMESObject().name
		print type(nl)

	if tableOn: tableObj.data = system.dataset.clearDataset(tableObj.data)
	cnt = 0
	if len(nextlots) > 0:
		if tableOn:
			dataset = tableObj.data
			headers = ['Lot','Status']
			data = []
		ml = nextlots[0].getMESObject()
		if tableOn:
			data.append([nextlots[0],ml.getPropertyValue('LotStatus')])
		else:
			print ml.name
		if tableOn: tableObj.data = system.dataset.toDataSet(headers,data)
		cnt = 1
				
	i = 0
	for nl in nextlots:
		if i >= 1:
			ml = nextlots[i].getMESObject()
			if tableOn: tableObj.data = system.dataset.addRow(tableObj.data,[nl,ml.getPropertyValue('LotStatus')])
			else: print ml.name
			cnt = cnt + 1
		i = i + 1
	return cnt