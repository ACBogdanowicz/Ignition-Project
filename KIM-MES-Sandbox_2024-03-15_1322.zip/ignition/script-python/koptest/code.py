""" koptest """
import system
def fetchResults(basename):
  # get results based on introspection of the mes folder
  # common routine for all systems
  #print ('fetchResults=================================================================')
  reslist = []
  opName = system.tag.readBlocking([basename + '/SFC_Interaction/CycleOperation'])[0]
  
  pywrap = system.tag.browse(basename + '/' + opName.value)
  results = pywrap.getResults()
  return results
  
def unpack(item):
	print 'unpack'
	print (item)
	for inner in item:
		print inner
		
def unwrap(pywrap):
 	print ( pywrap )
 	print "-items-"
 	for item in pywrap:
 		unpack( item )
 	
 	
def convertPyWrap(pywrap):
  reslist = []
  segdict = {}
  lotdict = {}
  for result in results:
	print ( result )
	print ('name: ' + result['name'])
	print result.keys()
  print 'ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ'

  for result in results:
   try:
	print ( result )
	print ('name: ' + result['name'])
	print result.keys()
	if result['hasChildren'] == False:
		#if result['dataType'] not in ['Folder']:
		if result['name'] not in segdict.keys():
			segdict[result['name']] = []
		segdict[result['name']].append(result['name'])
		segdict[result['name']].append(result['dataType'])
		segdict[result['name']].append(result['value'].value)
	else:
		#print 'Material Locations'
		#print result['fullPath']
		locpywrap = system.tag.browse(result['fullPath'])
		locresults = locpywrap.getResults()
		#print 'Location %s' % result['name']
		if result['name'] not in ['preset','Preset','presets','Presets','PRESET','PRESETS']:
		 if result['name'] not in lotdict.keys():
		 		lotdict[result['name']] = {}
		 	
		 	
		 for locresult in locresults:
			if locresult['hasChildren'] == False:
					attrdict = lotdict[result['name']]
					attrdict[locresult['name']] = []
				
					if locresult['name'] not in lotdict[result['name']]:
						loc
					attrdict[locresult['name']].append(locresult['dataType'])
					attrdict[locresult['name']].append(locresult['value'])
   except:
   	raise
				
  reslist.append(segdict)
  reslist.append(lotdict)
  #print ('========================================================================fetchResults')
  return reslist


def showResults(reslist):
   print 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
   for k in reslist[0].keys():
	print reslist[0][k]
   print 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
   print '-------'
   for k in reslist[1].keys():
 		print (k, '-------')
  		for vn in reslist[1][k].keys():
  			print (reslist[1][k][vn])