import system
TRANSACTIONLOCATION = "C:/Users/tr20131/Desktop/localignition/transactionfiles"
def start(basepath,equipmentpath,startdate):
	eqobj = system.mes.loadMESObjectByEquipmentPath(equipmentpath)
	filepath = '%s/%s.xml' % (TRANSACTIONLOCATION,eqobj.name)
	if not system.file.fileExists(filepath):
		system.file.writeFile(filepath,'<%s-begin>' % eqobj.name)
	#txt = system.file.openFile(filepath)
	system.file.writeFile(filepath,'<start date="%s">' % system.date.parse(system.date.now),1)
	system.file.writeFile(filepath,'<basepath>%s</basepath>' % basepath,1)

def createFile():
	fpath = system.file.openFile('xml',"C:\Users\tr20131\Desktop\localignition\transactions")
	print fpath
	tfile = system.file.getTempFile('txns')
	print tfile
	print system.file.writeFile('%stest.txns' % TRANSACTIONLOCATION,'start')
	
def testtransactions():
	#filepath = system.file.openFile('txns')
	#start('xxbasepathxx','Kaiser\KAW\Casting\DC0\DC0-Pit',system.date.parse(system.date.now()))
	createFile()
	