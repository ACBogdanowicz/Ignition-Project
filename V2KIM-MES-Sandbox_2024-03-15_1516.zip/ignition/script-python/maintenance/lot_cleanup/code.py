def clearSlabTracking():
	import system
	filter = system.mes.lot.filter.createFilter()
	filter.setModeName('LOT')
	filter.setLotEquipmentNameFilter('Slab Tracking')
	filter.setIncludeActiveLots(True)
	filter.setIncludeInactiveLots(True)
	filter.setMaxResults(500)
	#customPropertyValue = "MaterialLot.StatusCode=FP"

	#list = filter.parseCustomPropertyValueFilter(customPropertyValue)
	#filter.setCustomPropertyValueFilter(list)

	from java.util import Calendar
	beginCal = Calendar.getInstance()
	beginCal.add(Calendar.MONTH, -4)
	filter.setBeginDateTime(beginCal)
	endCal = Calendar.getInstance()
	filter.setEndDateTime(endCal)
	results = system.mes.getLotList(filter)
	print len(results)
	i = 1
	for link in results:
	 try:
		print i
		print str( link.getName() )
		ml = link.getMESObject()
		print ml.getUUID()
		print ml.getLotSequence()
		print ml.getPropertyValue('LotStatus')
		#ml.setPropertyValue('LotStatus','Used')
		#print ml.getPropertyValue('LotStatus')
		i = i + 1
	 except:
		raise