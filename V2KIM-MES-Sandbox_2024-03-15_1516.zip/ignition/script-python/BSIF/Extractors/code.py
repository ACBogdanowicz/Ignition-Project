import BSIF.Boomi
#
# import BSIF
# jb = 7243941
# print BSIF.Extractors.getThermalCode(jb)
# print BSIF.Extractors.getBatchCode(jb)
def getWagonLotSummary(lot):
	ldata = BSIF.Boomi.getRossLotInfoBoomi(lot)
	hljob = ''
	for item in ldata['LOT']['HISTORY']:
		print item
		if item['STAGE'] in ['HR132','HR112','HR80']:
			hljob = item['JOB']
		break

	##thcode = BSIF.Extractors.getThermalCode(hljob)
	#bacode = BSIF.Extractors.getBatchCode(hljob)
	#return hljob + thcode + ' ' + bacode
	print lot
	print hljob
	return hljob

def getThermalCodeForLot(lot):
	ldata = BSIF.Boomi.getRossLotInfoBoomi(lot)
	hljob = ''
	for item in ldata['LOT']['HISTORY']:
		if item['STAGE'] in ['HR132','HR112','HR80']:
			hljob = item['JOB']
			break
	return getThermalCode(hljob)
	
def getBatchCodeForLot(lot):
		ldata = BSIF.Boomi.getRossLotInfoBoomi(lot)
		hljob = ''
		for item in ldata['LOT']['HISTORY']:
			if item['STAGE'] in ['HR132','HR112','HR80']:
				hljob = item['JOB']
				break
		return getBatchCode(hljob)

def getThermalCode(job):
	stagelist = BSIF.Boomi.getRossJobStagesBoomi(job)
	for stage in stagelist:
		if stage[0:3] in [ 'HHT', 'SAL' ]:
			jsb = BSIF.Boomi.getRossJobStageBoomi(job,stage)
			#pprint.pprint(jsb['current_stage']['lines']['outputs'][0])
			outputs = jsb['current_stage']['lines']['outputs']
			#print len(outputs)
			#print outputs[0]['test_group']
			#for k in outputs[0].keys():
			#	print k
			ttarray = outputs[0]['test_codes']
			for item in ttarray:
				#print item['name'], item['value_planned']
				if item['name'] == 'THERML':
					return item['value_planned'] 
					
def getBatchCode(job):
	stagelist = BSIF.Boomi.getRossJobStagesBoomi(job)
	for stage in stagelist:
		if stage[0:4] in [ 'BAIR', 'BINR' ]:
			jsb = BSIF.Boomi.getRossJobStageBoomi(job,stage)
			#pprint.pprint(jsb['current_stage']['lines']['outputs'][0])
			outputs = jsb['current_stage']['lines']['outputs']
			#print len(outputs)
			#print outputs[0]['test_group']
			#for k in outputs[0].keys():
			#	print k
			ttarray = outputs[0]['test_codes']
			for item in ttarray:
				#print item['name'], item['value_planned']
				if item['name'] == 'THERML':
					return item['value_planned'] 

