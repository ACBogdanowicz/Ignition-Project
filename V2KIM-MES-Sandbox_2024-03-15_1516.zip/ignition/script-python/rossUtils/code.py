import xml.etree.ElementTree as ET

def elementAsLotRow(el,tbl):
	""" return a parent-lot element if it exists else None """
	parent = []
	pno = ''
	stage = ''
	acd = ''
	gau = 0.0
	ln = 0.0
	wid = 0.0
	jno = 0
	for child in el:
		if child.tag == 'PART-CODE':
			pno = child.text
		if child.tag == 'PROCESS-STAGE':
			stage = child.text
		if child.tag == 'PROCESS-STAGE':
			stage = child.text
		if child.tag == 'KA-CAST-DROP-ACD':
			acd = child.text
		if child.tag == 'JOB-NUMBER':
			jno = child.text
		if child.tag == 'CHARACTERISTIC' and child.attrib['id'] == 'GAUGE':
			gau = child.find('CHARACTERISTIC-NUMERIC').text
		if child.tag == 'CHARACTERISTIC' and child.attrib['id'] == 'LENGTH':
			ln = child.find('CHARACTERISTIC-NUMERIC').text
		if child.tag == 'CHARACTERISTIC' and child.attrib['id'] == 'WIDTH':
			wid = child.find('CHARACTERISTIC-NUMERIC').text
		if child.tag == 'PARENT-LOT':
			parent.append(child)
		
	lst = [stage,pno,gau,ln,wid,jno]
	tbl.addRow(lst)
	return parent

def parseLot(lotno):	
	url = 'http://erpap1.kaiseraluminum.com/cgi-bin/query/lot_query.sh?prod+' + lotno
	lotqrytext = system.net.httpGet(url)
	root = ET.fromstring(lotqrytext)
	return root
	
def elementAsJobRow(el,tbl):
		""" return a parent-lot element if it exists else None """
		stage = ''
		seq = 0
		start = ''
		end = ''
		stage =el.attrib['id']
		seq = el.attrib['flowseq']
		for child in el:	
			if child.tag == 'ACTUAL-START-DATE':
				start = child.text
			if child.tag == 'ACTUAL-CLOSE-DATE':
				end = child.text
				
		lst = [stage,seq,start,end]
		tbl.addRow(lst)
		
def parseJob(jno):
	url = 'http://erpap1.kaiseraluminum.com/cgi-bin/query/job_query.sh?prod+' + str(jno)
	jobqrytext = system.net.httpGet(url)
	root = ET.fromstring(jobqrytext)
	return root