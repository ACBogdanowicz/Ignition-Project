import system

logname = 'Setup - RossData'
def FullLot(lot):
    if len(lot)<7:
        try:
            even = int(lot[0]) + int(lot[2]) + int(lot[4])
            odds = '%d%d%d' % (2 * int(lot[1]), 2 * int(lot[3]), 2 * int(lot[5]))
            odd = 0
            for od in odds:
                odd = odd + int(od)
            total = odd + even
        except:
            print ('unable to calc check digit for %s' % lot)
            return lot
        checkdigit = (10 - total % 10) % 10
        if lot[0] in ['1']:  # rollover
            letter = 'C'
        else:
            letter = 'B'
        if lot[0:2] == '70':  # rollover for diverted
            letter = 'C'
        else:
            letter = 'B'
        newlot = lot[0:6] + letter + '%d' % checkdigit

    else:
        newlot = lot

    if newlot != "":
        return newlot
    else:
        return lot
        
def getRossBinInfoBoomi(bin):
	lotlist = []
	lotdata = {}
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/bin?Bin=" + str(bin)
	#print BoomyEndpoint
	jsonstr = system.net.httpGet(BoomyEndpoint)
	bindata = system.util.jsonDecode(jsonstr)
	for blot in bindata['BIN']['DETAIL']:
		lotdata[blot['LOT_NUMBER']]              = {}
		lotdata[blot['LOT_NUMBER']]['PART_CODE'] = blot['PART_CODE']
		lotdata[blot['LOT_NUMBER']]['STATUS']    = blot['STATUS']
	#print stages
	return lotdata	
		
def updateRossJob(Tagpath):
	import pprint
	updateDict_Raw = {}
	updateDict = {}
	updateDict['JOB_UPDATE'] = {}
	
	#Update QC_Results to array for Json format
	updateDict_Raw = system.tag.readBlocking(Tagpath)[0].value
	
	updateDict['JOB_UPDATE']['HEADER'] = {}
	updateDict['JOB_UPDATE']['HEADER'] = dict(updateDict_Raw['HEADER'])
	
	updateDict['JOB_UPDATE']['CAST_COUNTS'] = {}
	updateDict['JOB_UPDATE']['CAST_COUNTS'] =  dict(updateDict_Raw['CAST_COUNTS'])
		
	updateDict['JOB_UPDATE']['MATERIAL_ISSUE'] = {}
	updateDict['JOB_UPDATE']['MATERIAL_ISSUE'] = dict(updateDict_Raw['MATERIAL_ISSUE'])
	
	updateDict['JOB_UPDATE']['OUTPUT_COUNTS'] = {}
	updateDict['JOB_UPDATE']['OUTPUT_COUNTS'] = dict(updateDict_Raw['OUTPUT_COUNTS'])	
	
	updateDict['JOB_UPDATE']['STAGE_CLOSE'] = {}
	updateDict['JOB_UPDATE']['STAGE_CLOSE'] = dict(updateDict_Raw['STAGE_CLOSE'])	
	
	index = 0
	updateDict['JOB_UPDATE']['QC_RESULTS'] = []
	while index < 10:
		#print index
		if updateDict_Raw['QC_RESULTS'][str(index)]['RESULT'] != "":
			updateDict['JOB_UPDATE']['QC_RESULTS'].append(dict(updateDict_Raw['QC_RESULTS'][str(index)]))
		index = index + 1
	
	#Encode JSON for ROSS consume
	#pprint.pprint(updateDict)
	
	submit = system.util.jsonEncode(updateDict)
	#print pprint.pprint(submit)
	
	#Temporary write to HDD for testing with Janice
	#filename = system.file.saveFile(Tagpath[15:] +".json")
	#if filename is not None:
	#	  system.file.writeFile(filename, submit)
	BoomyEndpoint = "http://frpbmtest.kaiseraluminum.com/ws/rest/PFT/Stage"
	#print BoomyEndpoint
	success = system.net.httpPost(BoomyEndpoint, "application/json", str(submit))
	#success = 0
	return success	
						
def getRossSchedInfoBoomi(Stage, Date):
	joblist  = []
	schedret = {}
	
	datestr       = system.date.format(Date,'YYYYMMdd')
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/schedule/?Date=%s&Stage=%s" % (datestr, str(Stage))
	#print BoomyEndpoint
	jsonstr   = system.net.httpGet(BoomyEndpoint)
	scheddata = system.util.jsonDecode(jsonstr)
	for bjob in scheddata['schedule']['jobs']:
		schedret[bjob['Job_number']] = {}
		schedret[bjob['Job_number']]['actual_machine']    = bjob['actual_machine']
		schedret[bjob['Job_number']]['actual_start_date'] = bjob['actual_start_date']
		schedret[bjob['Job_number']]['batch_id']          = bjob['batch_id']
		schedret[bjob['Job_number']]['planned_machine']   = bjob['planned_machine']
		schedret[bjob['Job_number']]['process_stage']     = bjob['process_stage']
		schedret[bjob['Job_number']]['schedule_es_date']  = bjob['schedule_es_date']
		#lotdata[blot['LOT_NUMBER']]['STATUS']=blot['STATUS']
	#print stages
	return schedret	
										
def getRossLotInfoBoomi(Lot):
	stagelist     = []
	lotdata       = {}
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/lot/" + str(Lot)
	#BoomyEndpoint = "http://frpbmtest.kaiseraluminum.com/ws/rest/erp/lot/?Lot=" + str(Lot)
	#print BoomyEndpoint
	jsonstr       = system.net.httpGet(BoomyEndpoint)
	lotdata       = system.util.jsonDecode(jsonstr)

	#print stages
	return lotdata	
	
def GetPracticeInfo(PracNum, exitgauge, exitwidth):
	import xmltodict
	import pprint
	from collections import OrderedDict
	#from lxml import etree as etree
	htmlInfo = {}
	exitgauge = float(exitgauge)
	exitwidth = float(exitwidth)
	
	#querystr = "http://frpdb05/cgi-bin/IngWebRW.sh?REPORT_practice_no=" +str(PracNum) + "&ii_database=pms_prod$%3A%3Ahotline&ii_report=hl_practice_data&ii_errormsg=***ERROR***"
	querystr = "http://frpbmp.kaiseraluminum.com/ws/rest/passthrough/qualitypractice?Number=" +str(PracNum) + "&DB=pms_prod$%3A%3Ahotline&Report=hl_practice_data"
	returnstr = system.net.httpGet(querystr)
	#print returnstr
	#system.util.getLogger('FPY.Schedule.Ingress').info(querystr)	#log it
		
	try:
		returndict = xmltodict.parse(returnstr)
	except:
		#Retry on fail - once.
		returndict = xmltodict.parse(returnstr)
	pprint.pprint(returndict)
	recipedata ={}
	
	#Test width
	for recipe in returndict['Event']['practice_info']['HOTLINE']:
		if type(returndict['Event']['practice_info']['HOTLINE'][recipe]) == OrderedDict:
			if 'Width' in returndict['Event']['practice_info']['HOTLINE'][recipe].keys():
				recipedata[recipe] = {}
				widthfound = 0
				for row in returndict['Event']['practice_info']['HOTLINE'][recipe]['Width']:
					if widthfound == 1:
						break
					if type(row) == OrderedDict and widthfound == 0:
						for i, (key, val) in enumerate(row.items()):
							if '@pcs' != key and '@datatype' != key and '@description' != key :
								#assumes value happens before recipe since its an ordered dictionary
								if key == '@value':
									widthtest = float(row[key])
									if widthtest > exitwidth:
										widthfound = 1
										break
								else:
									recipedata[recipe][key] = {}
									recipedata[recipe][key] = row[key]['#text']
					else:	#is a key instead of an ordered dictionary. Likely just one width with one set of keys then.
						key = str(row)
						row = returndict['Event']['practice_info']['HOTLINE'][recipe]['Width']	#the level above is the row...
						if '@pcs' != key and '@datatype' != key and '@description' != key and '@value' != key :
							#system.util.getLogger('FPY.Schedule.Ingress').info(str(key)+'---'+str(row[key]['#text']))
							recipedata[recipe][key] = {}
							recipedata[recipe][key] = row[key]['#text']

	#Test ExitGauge
	for recipe in returndict['Event']['practice_info']['HOTLINE']:
		if type(returndict['Event']['practice_info']['HOTLINE'][recipe])== OrderedDict:
			if 'ExitGauge' in returndict['Event']['practice_info']['HOTLINE'][recipe].keys():
				recipedata[recipe] = {}
				gaugefound = 0
				for row in returndict['Event']['practice_info']['HOTLINE'][recipe]['ExitGauge']:
					if gaugefound == 1:
						break
					#system.util.getLogger('FPY.Schedule.Ingress').info(str(row))
					if type(row) == OrderedDict and gaugefound == 0:
						for i, (key, val) in enumerate(row.items()):
							if '@pcs' != key and '@datatype' != key and '@description' != key :
								#assumes value happens before recipe since its an ordered dictionary
								if key == '@value':
									gaugetest = float(row[key])
									if gaugetest > exitgauge:
										gaugefound = 1
										break
								else:
									#system.util.getLogger('FPY.Schedule.Ingress').info(str(key)+'---'+str(row[key]['#text']))
									recipedata[recipe][key] = {}
									recipedata[recipe][key] = row[key]['#text']
					else:	#is a key instead of an ordered dictionary. Likely just one gauge with one set of keys then.
						key = str(row)
						row = returndict['Event']['practice_info']['HOTLINE'][recipe]['ExitGauge']	#the level above is the row...
						if '@pcs' != key and '@datatype' != key and '@description' != key and '@value' != key :
							#system.util.getLogger('FPY.Schedule.Ingress').info(str(key)+'---'+str(row[key]['#text']))
							recipedata[recipe][key] = {}
							recipedata[recipe][key] = row[key]['#text']
	#system.util.getLogger('FPY.Schedule.Ingress').info(str(recipedata))
	#Test Tension
	for recipe in returndict['Event']['practice_info']['HOTLINE']:
		if type(returndict['Event']['practice_info']['HOTLINE'][recipe])== OrderedDict:
			if 'Tension' in returndict['Event']['practice_info']['HOTLINE'][recipe].keys():
				recipedata[recipe] = {}
				recipedata[recipe]['Tension'] = {}
				recipedata[recipe]['Tension'] = returndict['Event']['practice_info']['HOTLINE'][recipe]['Tension']['#text']
				
	return recipedata
	
def getRossJobStagesBoomi(job):
	#import pprint
	stagelist     = []
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/" + str(job)
	jsonstr       = system.net.httpGet(BoomyEndpoint)
	jobdict       = system.util.jsonDecode(jsonstr)
	#pprint.pprint(jobdict['stages'])
	for stagedict in jobdict['stages']:
		stagelist.append(stagedict['name'])
	#print stages
	return stagelist
		
def getRossJobBoomi(job):
	#import pprint
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/" + str(job)
	jsonstr       = system.net.httpGet(BoomyEndpoint)
	jobdict       = system.util.jsonDecode(jsonstr)
	#print stages
	return jobdict
		
					
def getRossCurrStageBoomi(job):
	#import pprint
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/" + str(job)
	jsonstr       = system.net.httpGet(BoomyEndpoint)
	jobdict       = system.util.jsonDecode(jsonstr)
	#print stages
	return jobdict['current_stage']

		
def getRossJobStageBoomi(job, stage):
		#import pprint
	BoomyEndpoint = "http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/%s/%s" % (str(job),str(stage))
	jsonstr       = system.net.httpGet(BoomyEndpoint)
	jobdict       = system.util.jsonDecode(jsonstr)
	#print stages
	return jobdict
	
		

def janicetest():
	job = 0
	stage = ''
	lot = ''
	
	count = "1"
	
	qcrtc1 =''
	qcr1_TC = ''
	qcr1_UOM = ''
	qcr1_Result = ''
	
	qcrtc2 =''
	qcr2_TC = ''
	qcr2_UOM = ''
	qcr2_Result = ''
	
	qcrtc3 =''
	qcr3_TC = ''
	qcr3_UOM = ''
	qcr3_Result = ''
	
	qcrtc4 =''
	qcr4_TC = ''
	qcr4_UOM = ''
	qcr4_Result = ''
	
	datenow = system.date.now()
	datestr = system.date.format(datenow, "dd-MMM-yyyy HH:mm")
	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/JOB_NUMBER', job)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/PROCESS_STAGE', stage)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/DATESENT', datestr)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/MI_SENT', 'N')
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/QCR_SENT', 'N')
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/COUNT_SENT', 'N')
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/HEADER/KCLOSE_SENT', 'N')
	
	#Issue material for core		
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/MATERIAL_ISSUE/LOT_NUMBER_OR_PART', lot)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/MATERIAL_ISSUE/RECIPE_LINE','30')
	
	#Return QCR for gauge
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/0/RESULT', "%s" % qcr1_Result)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/0/RESULT_UOM', "%s" % qcr1_UOM)	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/0/SEQUENCE', "0")	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/0/TEST_GROUP', qcrtc1)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/0/TEST_CODE', "%s" % qcr1_TC)	
	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/1/RESULT', "%s" % qcr2_Result)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/1/RESULT_UOM', "%s" % qcr2_UOM)	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/1/SEQUENCE', "0")	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/1/TEST_GROUP', qcrtc2)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/1/TEST_CODE', "%s" % qcr2_TC)	
	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/2/RESULT', "%s" % qcr3_Result)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/2/RESULT_UOM', "%s" % qcr3_UOM)	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/2/SEQUENCE', "0")	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/2/TEST_GROUP', qcrtc3)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/2/TEST_CODE', "%s" % qcr3_TC)	
	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/3/RESULT', "%s" % qcr4_Result)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/3/RESULT_UOM', "%s" % qcr4_UOM)	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/3/SEQUENCE', "0")	
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/3/TEST_GROUP', qcrtc4)
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/QC_RESULTS/3/TEST_CODE', "%s" % qcr4_TC)	
	
	
	#Count Lot to Job
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/OUTPUT_COUNTS/COUNT_QTY', count )
	system.tag.writeBlocking('[STS_Tags]Clad/CORE_UPDATE/OUTPUT_COUNTS/LOT_NUMBER', lot)
	
	#Ussue to Boomi
	updateRossJob('[STS_Tags]Clad/CORE_UPDATE')	