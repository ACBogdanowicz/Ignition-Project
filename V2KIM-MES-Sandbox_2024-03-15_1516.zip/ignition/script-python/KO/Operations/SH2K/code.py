import system
def Trim(equipPath,basetagpath,logger):

	logger.info('Shr2ktTrim - operation start')
	optagpath = basetagpath + '/' + 'Shr2ktTrim'
	lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
	inlot = lottags[0]
	if KO.utils.lotCheckLog(lottags[0].value,'Shr2ktTrim',0):
	
		endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
		startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value

		inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
		inlotobj = system.mes.loadMaterialLot(inlot,-1,0)
		inlotseq = inlotobj.getLotSequence()
		inqty = inlotobj.getLotInventory().getNetQuantity()
		
		flds = system.tag.readBlocking([optagpath + '/Head Trim/headTrimLength',optagpath + '/Tail Trim/tailTrimLength',optagpath + '/Material Out/Length',optagpath + '/Material Out/Width',optagpath + '/Material Out/Thickness'])
		headTrimLength = flds[0].value
		tailTrimLength = flds[1].value
		outLength = flds[2].value
		outWidth = flds[3].value
		outThickness = flds[4].value
		
		totalLength = headTrimLength + tailTrimLength + outLength
		lbsperin = inqty/totalLength
		
		outqty = inqty
		if headTrimLength > 0:
			system.tag.writeBlocking([optagpath + '/Head Trim/Quantity',optagpath + '/Head Trim/Lot'],[headTrimLength * lbsperin,'HeadScrap_%s_%s' % (inlotseq,inlot)])
			outqty = outqty - (headTrimLength * lbsperin)
		else:			
			system.tag.writeBlocking([optagpath + '/Head Trim/Quantity',optagpath + '/Head Trim/Lot'],[headTrimLength * lbsperin,''])
			
		if tailTrimLength > 0:
				system.tag.writeBlocking([optagpath + '/Tail Trim/Quantity',optagpath + '/Tail Trim/Lot'],[tailTrimLength * lbsperin,'TailScrap_%s_%s' % (inlotseq,inlot)])
				outqty = outqty - (tailTrimLength * lbsperin)
		else:			
				system.tag.writeBlocking([optagpath + '/Tail Trim/Quantity',optagpath + '/Tail Trim/Lot'],[tailTrimLength * lbsperin,''])
			
		system.tag.writeBlocking([optagpath + '/Material Out/Quantity'],[outqty])

		logger.info('setup complete')
		try:
			ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)

			ko.createSegment()
			ko.setSegmentProperties()
			ko.setSegmentMaterials()

			ko.seg = ko.seg.begin(startts)
			ko.updateSegmentMaterialProperties()
			ko.seg = ko.seg.update()

			ko.seg = ko.seg.update()
			ko.seg.end(endts)
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				[system.date.now(),'complete'])
			logger.info('complete')
			return 1
 
		except:
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				['','Exception'])
			logger.info('Exception')

			return 0
			
	return 0
	
def Part(equipPath,basetagpath,logger):
	
		logger.info('Shr2ktPart - operation start')
		optagpath = basetagpath + '/' + 'Shr2ktPart'
		lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
		inlot = lottags[0]
		if KO.utils.lotCheckLog(lottags[0].value,'Shr2ktPart',0):
		
			endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
			startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value

			inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
			ml = system.mes.loadMaterialLot(inlot,-1,0)
			inqty = ml.getLotInventory().getNetQuantity()
			inLength = float(ml.getPropertyValue('Length'))
			
			flds = system.tag.readBlocking([optagpath + '/Material Out/Length',optagpath + '/Material Out/Width',optagpath + '/Material Out/Thickness'])

			outLength = float(flds[0].value)
			outWidth = float(flds[1].value)
			outThickness = float(flds[2].value)
					
			outqty = inqty * (outLength/inLength)
			resqty = inqty - outqty
				
			system.tag.writeBlocking([optagpath + '/Material Out/Quantity'],[outqty])
			system.tag.writeBlocking([optagpath + '/Remainder/Quantity'],[resqty])
			system.tag.writeBlocking([optagpath + '/Remainder/Length'],[(inLength - outLength)])
			system.tag.writeBlocking([optagpath + '/Remainder/Thickness'],[outThickness])
			system.tag.writeBlocking([optagpath + '/Remainder/Width'],[outWidth])
	
	
			logger.info('setup complete')
			try:
				ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
	
				ko.createSegment()
				ko.setSegmentProperties()
				ko.setSegmentMaterials()
	
				ko.seg = ko.seg.begin(startts)
				ko.updateSegmentMaterialProperties()
				ko.seg = ko.seg.update()
	
				ko.seg = ko.seg.update()
				ko.seg.end(endts)
				system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
					basetagpath + '/Interaction/reportErrorNotification'],
					[system.date.now(),'complete'])
				logger.info('complete')
				return 1
	 
			except:
				system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
					basetagpath + '/Interaction/reportErrorNotification'],
					['','Exception'])
				logger.warn('Exception %s' % inlot)
				raise
				return 0
				
		return 0

def Split(equipPath,basetagpath,logger):
			
	logger.info('Shr2ktSplit - operation start')
	optagpath = basetagpath + '/' + 'Shr2ktSplit'
	lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
	inlot = lottags[0]
	if KO.utils.lotCheckLog(lottags[0].value,'Shr2ktSplit',0):
				
		endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
		startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value
		
		inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
		ml = system.mes.loadMaterialLot(inlot,-1,0)
		inqty = ml.getLotInventory().getNetQuantity()
		inLength = float(ml.getPropertyValue('Length'))
					
		flds = system.tag.readBlocking([optagpath + '/Material Out/Length',optagpath + '/Material Out/Width',optagpath + '/Material Out/Thickness'])
		
		outLength = float(flds[0].value)
		outWidth = float(flds[1].value)
		outThickness = float(flds[2].value)
							
		outqty = inqty * (outLength/inLength)
		resqty = inqty - outqty
						
		system.tag.writeBlocking([optagpath + '/Material Out/Quantity'],[outqty])
		system.tag.writeBlocking([optagpath + '/Remainder/Quantity'],[resqty])
		system.tag.writeBlocking([optagpath + '/Remainder/Length'],[(inLength - outLength)])
		system.tag.writeBlocking([optagpath + '/Remainder/Thickness'],[outThickness])
		system.tag.writeBlocking([optagpath + '/Remainder/Width'],[outWidth])
			
			
		logger.info('setup complete')
		try:
			ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
			
			ko.createSegment()
			ko.setSegmentProperties()
			ko.setSegmentMaterials()
			
			ko.seg = ko.seg.begin(startts)
			ko.updateSegmentMaterialProperties()
			ko.seg = ko.seg.update()
			
			ko.seg = ko.seg.update()
			ko.seg.end(endts)
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				[system.date.now(),'complete'])
			logger.info('complete')
			return 1
			 
		except:
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				['','Exception'])
			logger.info('Exception')
			raise
			return 0
						
	return 0
				
def Scrap(equipPath,basetagpath,logger):
		
			logger.info('Shr2ktScrap - operation start')
			optagpath = basetagpath + '/' + 'Shr2ktScrap'
			lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
			inlot = lottags[0]
			if KO.utils.lotCheckLog(lottags[0].value,'Shr2ktTrim',0):
			
				endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
				startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value
		
				inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
				ml = system.mes.loadMaterialLot(inlot,-1,0)
				inlotseq = ml.getLotSequence()
				inqty = ml.getLotInventory().getNetQuantity()
				inLength = ml.getPropertyValue('Length')
				inWidth = ml.getPropertyValue('Width')
				inThickness = ml.getPropertyValue('Thickness')
				
				system.tag.writeBlocking([optagpath + '/Scrap/Quantity'],[inqty])
				system.tag.writeBlocking([optagpath + '/Scrap/Lot'],['PieceScrap_%s_%s' % (inlotseq,inlot)])
				system.tag.writeBlocking([optagpath + '/Scrap/Length'],[inLength])
				system.tag.writeBlocking([optagpath + '/Scrap/Thickness'],[inThickness])
				system.tag.writeBlocking([optagpath + '/Scrap/Width'],[inWidth])
		
				logger.info('setup complete')
				try:
					ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
		
					ko.materials['Material In'].quantity = inqty
		
					ko.createSegment()
					ko.setSegmentProperties()
					ko.setSegmentMaterials()
		
					ko.seg = ko.seg.begin(startts)
					ko.updateSegmentMaterialProperties()
					ko.seg = ko.seg.update()
		
					ko.seg = ko.seg.update()
					ko.seg.end(endts)
					system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
						basetagpath + '/Interaction/reportErrorNotification'],
						[system.date.now(),'complete'])
					logger.info('complete')
					return 1
		 
				except:
					system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
						basetagpath + '/Interaction/reportErrorNotification'],
						['','Exception'])
					logger.info('Exception')
					raise
					return 0
					
			return 0