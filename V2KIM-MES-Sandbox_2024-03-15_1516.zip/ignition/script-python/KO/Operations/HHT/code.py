def MovePlateToPresetTable(equipPath,basetagpath,logger):
	fromloc,toPos = system.tag.readBlocking([basetagpath + '/WagonLocationName',basetagpath + '/PresetLocation'])
	logger.info('MovePlateToPresetTable %s %s' % (fromloc.value,toPos.value))

	presetLocObj = system.mes.getMESObjectLinkByName('LineCell',toPos.value).getMESObject()
	# preset location must be available
	pseg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
	pnextlots = pseg.getAvailableMaterialLots('Material In',presetLocObj.equipmentPath)
	ml = None
	if len(pnextlots) == 0:
		logger.info('preset location available')
	
		suObj = system.mes.getMESObjectLinkByName('StorageUnit',fromloc.value).getMESObject()
	
		logger.info(suObj.name)
		useg = system.mes.createSegment('placeOnFloor','Kaiser\KAW\Admin\Handling',True)
		sunextlots = useg.getAvailableMaterialLots('Material In',suObj.equipmentPath)
		logger.info(str(sunextlots))
		if len(sunextlots) == 0:
			logger.info('no lots on floor')
	
			wags = Wagon.getWagonsForLocation(suObj.equipmentPath)
			logger.info(str(wags))
			if len(wags) == 0:
				logger.info('no wagon at location')
				locationPath = suObj.equipmentPath
			else:
				logger.info('use top plate on %s' % wags[0])
				seg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
				nextlots = seg.getAvailableMaterialLots('Material In',str(wags[0]))
				if len(nextlots) > 0:
					logger.info(nextlots[0].name)
					ml = system.mes.loadMaterialLot(nextlots[0].name,-1,0)
				else:
					logger.info('no plates left on wagon')
		else:
			logger.info('use top plate on floor')
			seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
			nextlots = seg.getAvailableMaterialLots('Material In',suObj.equipmentPath)
			if len(nextlots) > 0:
					logger.info(nextlots[0].name)
					ml = system.mes.loadMaterialLot(nextlots[0].name,-1,0)
		if ml != None:
			logger.info('ml')
			seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
			qty = ml.getLotInventory().getNetQuantity()
			logger.info(str(qty))
		
			seg.setMaterial('Material In',ml.name)
			seg.setMaterial('Material Out','Plate',presetLocObj.equipmentPath,ml.name,qty)
			seg.execute()


	return 1
	
def MovePlateToWagonOrFloor(equipPath,basetagpath,logger):
	toPos,fromloc = system.tag.readBlocking([basetagpath + '/WagonLocationName',basetagpath + '/PresetLocation'])
	logger.info('MovePlateToWagonOrFloor %s %s' % (toPos.value,fromloc.value))

	presetLocObj = system.mes.getMESObjectLinkByName('LineCell',fromloc.value).getMESObject()
	# preset location must be available
	pseg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
	pnextlots = pseg.getAvailableMaterialLots('Material In',presetLocObj.equipmentPath)
	logger.info(str(pnextlots[0]))
	ml = None
	destObj = None
	seg = None
	destId = None
	if len(pnextlots) > 0:
		logger.info('preset location occuppied')
		ml = system.mes.loadMaterialLot(str(pnextlots[0]),-1,0)
		qty = ml.getLotInventory().getNetQuantity()
		
		wags = Wagon.getWagonsForLocation('Kaiser\KAW\PlateFlow\Plate Flow Processing\%s' % toPos.value)
		logger.info(str(wags))
		if len(wags) == 0:
			logger.info('no wagon at location - place on top')
			destObj = system.mes.getMESObjectLinkByName('StorageUnit',toPos.value).getMESObject()
			seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
			destId = destObj.equipmentPath
		else:
			logger.info('wagon present - place on top')
			destObj = system.mes.getMESObjectLinkByName('Equipment',str(wags[0])).getMESObject()
			seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
			destId = str(wags[0])
		
		if seg != None:
			try:
				seg.setMaterial('Material In',ml.name)
				seg.setMaterial('Material Out','Plate',destId)
				seg.execute()
				return 1
			except:
				return 0
	
def Stage(equipPath,basetagpath,logger):

	logger.info('KO HHT Stage %s %s' % (equipPath,basetagpath))
	linename = equipPath.split('\\')[-1]
	logger.info('Stage -  %s' % linename)
	presetdatetime = None
	try:
			results = system.tag.readBlocking([basetagpath + '/HTStage/PresetDateTime',
				basetagpath + '/HTStage/North/Lot',
				basetagpath + '/HTStage/South/Lot',
				basetagpath + '/HTStage/Center/Lot'])
			presetdatetime = results[0]
			
			# here the plates need to be removed from wagons and place on the staging table
			# this bypasses the operator interaction and the output lot names need to be the
			# lots and pieces assigned at the furnace to be consistent with
				
			nsObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingNorth').getMESObject()
			csObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingCenter').getMESObject()
			ssObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingSouth').getMESObject()
			pseg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
			nslot = pseg.getAvailableMaterialLots('Material In',nsObj.equipmentPath)
			cslot = pseg.getAvailableMaterialLots('Material In',csObj.equipmentPath)
			sslot = pseg.getAvailableMaterialLots('Material In',ssObj.equipmentPath)
			
			if ( len(nslot) + len(cslot) + len(sslot) ) > 0:
				print 'STAGE TABLE IS NOT EMPTY'
			else:
				stageready = 1
			
			if stageready:
				operDef = system.mes.loadMESObject('Heat Treat Plate','OperationsDefinition')
				oper = system.mes.createOperation(operDef)
			
				result = system.mes.beginOperation(equipPath,oper)
				print result
			
				seg = system.mes.createSegmentForOperation(oper.getUUID(),'Heat Treat Stage',True)
				print 'seg: %s' % seg
				nObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'PresetNorth').getMESObject()
				cObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'PresetCenter').getMESObject()
				sObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'PresetSouth').getMESObject()
				pseg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
				nlot = pseg.getAvailableMaterialLots('Material In',nObj.equipmentPath)
				clot = pseg.getAvailableMaterialLots('Material In',cObj.equipmentPath)
				slot = pseg.getAvailableMaterialLots('Material In',sObj.equipmentPath)
				if len(nlot) > 0:
					print 'nlot:%s' % nlot[0].name
					seg.setMaterial('Material In North',nlot[0].name, -1, 0)
					qty = system.mes.loadMaterialLot(nlot[0].name,-1,0).getLotInventory().getNetQuantity()
					print qty
					seg.setMaterial('Material Out North','Plate',equipPath + '\\' + linename + 'Staging' +'\\' + linename + 'StagingNorth',nlot[0].name,qty)
				if len(clot) > 0:
					seg.setMaterial('Material In Center',clot[0].name, -1, 0)
					qty = system.mes.loadMaterialLot(clot[0].name,-1,0).getLotInventory().getNetQuantity()
					print qty
					seg.setMaterial('Material Out Center','Plate',equipPath + '\\' + linename + 'Staging' +'\\' + linename + 'StagingCenter',clot[0].name,qty)
					#seg.setMaterial('Material Out Center','Plate','Kaiser\KAW\PlateFlow\HHT4\HHT4Staging\HHT4StagingCenter',clot[0].name,qty)
				if len(slot) > 0:
					seg.setMaterial('Material In South',slot[0].name, -1, 0)
					qty = system.mes.loadMaterialLot(slot[0].name,-1,0).getLotInventory().getNetQuantity()
					print qty
					seg.setMaterial('Material Out South','Plate',equipPath + '\\' + linename + 'Staging' +'\\' + linename + 'StagingSouth',slot[0].name,qty)
					#seg.setMaterial('Material Out South','Plate','Kaiser\KAW\PlateFlow\HHT4\HHT4Staging\HHT4StagingSouth',slot[0].name,qty)
				seg.setPropertyValue('PresetDateTime',presetdatetime)
				seg = seg.execute()
					
				system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
					basetagpath + '/Interaction/reportErrorNotification'],
					[system.date.now(),'complete'])
				logger.info('complete')
				return 1
 
	except:
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				['','Exception'])
			logger.info('Exception')
			raise
			return 0
			
	return 0
	
def Feed(equipPath,basetagpath,logger):
 import KO
 oper = KO.multiopUtils.findFirst(equipPath,'Heat Treat Stage')
 print 'findFirst operation uuid: %s' % oper.getUUID()
 nlot = []
 slot = []
 clot = []
 linename = equipPath.split('\\')[-1]
 if oper != None:

	seg = system.mes.createSegmentForOperation(oper.getUUID(),'Heat Treat Feed',True)
	print 'seg: %s' % seg
	nObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingNorth').getMESObject()
	cObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingCenter').getMESObject()
	sObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingSouth').getMESObject()
	pseg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
	nlot = pseg.getAvailableMaterialLots('Material In',nObj.equipmentPath)
	clot = pseg.getAvailableMaterialLots('Material In',cObj.equipmentPath)
	slot = pseg.getAvailableMaterialLots('Material In',sObj.equipmentPath)
	if len(nlot) > 0:
		print 'nlot:%s' % nlot[0].name
		seg.setMaterial('Material In North',nlot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(nlot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		seg.setMaterial('Material Out North','Plate',equipPath,nlot[0].name,qty)
	if len(clot) > 0:
		seg.setMaterial('Material In Center',clot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(clot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		seg.setMaterial('Material Out Center','Plate',equipPath,clot[0].name,qty)
	if len(slot) > 0:
		print 'slot:%s' % slot[0].name
		seg.setMaterial('Material In South',slot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(slot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		seg.setMaterial('Material Out South','Plate',equipPath,slot[0].name,qty)
	
	seg = seg.execute()
	
	# below here creates the heat treatment segment and leave it active until offload
	print 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
	print 'nlot[0]',nlot[0].name
	print 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
	hseg = system.mes.createSegmentForOperation(oper.getUUID(),'Heat Treatment',True)
	
	if len(nlot) > 0:
		print 'nlot:%s' % nlot[0].name
		hseg.setMaterial('Material In North',nlot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(nlot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		hseg.setMaterial('Material Out North','Plate',equipPath,nlot[0].name,qty)
	if len(clot) > 0:
		hseg.setMaterial('Material In Center',clot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(clot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		hseg.setMaterial('Material Out Center','Plate',equipPath,clot[0].name,qty)
	if len(slot) > 0:
		print 'slot:%s' % slot[0].name
		hseg.setMaterial('Material In South',slot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(slot[0].name,-1,0).getLotInventory().getNetQuantity()
		print qty
		hseg.setMaterial('Material Out South','Plate',equipPath,slot[0].name,qty)

	hseg = hseg.begin()
	return 1
	
def Offload(equipPath,basetagpath,logger):
	
	operation = 'HTOffload'
	linename = equipPath.split('\\')[-1]
	import KO
	oper = None
	try:
 		oper = KO.multiopUtils.findLast(equipPath,'Heat Treatment')
 		seg = oper.getActiveSegment('Heat Treatment')
		print seg.getPropertyValue('BeginDateTime')
 		if seg.getPropertyValue('EndDateTime') == None:
			seg = seg.update()
			seg = seg.end()
	except:
		pass

	nml = None
	sml = None
	cml = None
	try:
		nml = seg.getMaterialLot('Material Out North')
	except:
		pass
	try:
		sml = seg.getMaterialLot('Material Out South')
	except:
		pass
	try:
		cml = seg.getMaterialLot('Material Out Center')
	except:
		pass

	pseg = system.mes.createSegmentForOperation(oper.getUUID(),'Heat Treat Offload',True)

	if nml != None:
		print 'nlot:%s' % nml.name
		pseg.setMaterial('Material In North',nml.name, -1, 0)
		qty = nml.getLotInventory().getNetQuantity()
		pseg.setMaterial('Material Out North','Plate',equipPath + '\\' + linename + 'Offload' + '\\' + linename + 'OffloadNorth',nml.name,qty)
	if cml != None:
		pseg.setMaterial('Material In Center',cml.name, -1, 0)
		qty = cml.getLotInventory().getNetQuantity()
		pseg.setMaterial('Material Out Center','Plate',equipPath + '\\' + linename + 'Offload' + '\\' + linename + 'OffloadCenter',cml.name,qty)
	if sml != None:
		pseg.setMaterial('Material In South',sml.name, -1, 0)
		qty = sml.getLotInventory().getNetQuantity()
		pseg.setMaterial('Material Out South','Plate',equipPath + '\\' + linename + 'Offload' + '\\' + linename + 'OffloadSouth',sml.name,qty)
	
	pseg = pseg.begin()
	pseg.end()
	return 1

def UnStage(equipPath,basetagpath,logger):
		
	import KO
	oper = None
	linename = equipPath.split('\\')[-1]

	oper = KO.multiopUtils.findLast(equipPath,'Heat Treat Stage')
	


	list = system.mes.getAvailableSegments(oper, 'Heat *')
	for ndx in range(list.size()):
   	 segments = list.get(ndx)
    	print segments
    
	print 'No Execute "Heat Treat UnStage"'

	seg = system.mes.createSegmentForOperation(oper.getUUID(),'Heat Treat Unstage',True)
	print 'seg: %s' % seg
	nObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingNorth').getMESObject()
	cObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingCenter').getMESObject()
	sObj = system.mes.getMESObjectLinkByName('LineCell',linename + 'StagingSouth').getMESObject()
	pseg = system.mes.createSegment('wagonTransfer','Kaiser\KAW\Admin\Handling',True)
	nlot = pseg.getAvailableMaterialLots('Material In',nObj.equipmentPath)
	clot = pseg.getAvailableMaterialLots('Material In',cObj.equipmentPath)
	slot = pseg.getAvailableMaterialLots('Material In',sObj.equipmentPath)
	if len(nlot) > 0:
		print 'nlot:%s' % nlot[0].name
		seg.setMaterial('Material In North',nlot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(nlot[0].name,-1,0).getLotInventory().getNetQuantity()
		seg.setMaterial('Material Out North','Plate',equipPath + '\\' + linename + 'Preset' + '\\' + linename + 'PresetNorth',nlot[0].name,qty)
	if len(clot) > 0:
		seg.setMaterial('Material In Center',clot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(clot[0].name,-1,0).getLotInventory().getNetQuantity()
		seg.setMaterial('Material Out Center','Plate',equipPath + '\\' + linename + 'Preset' + '\\' + linename + 'PresetCenter',clot[0].name,qty)
	if len(slot) > 0:
		seg.setMaterial('Material In South',slot[0].name, -1, 0)
		qty = system.mes.loadMaterialLot(nlot[0].name,-1,0).getLotInventory().getNetQuantity()
		seg.setMaterial('Material Out South','Plate',equipPath + '\\' + linename + 'Preset' + '\\' + linename + 'PresetSouth',slot[0].name,qty)
	
	seg = seg.begin()
	seg.end()
					
	return 0