def Trim(equipPath,basetagpath,logger):

	optagpath = basetagpath + '/' + 'IngotSawTrim'
	lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
	inlot = str(lottags[0].value)
	logger.info('IngotSawTrim - operation start ' + str(inlot))
	lbsperin = 0.0
	try:
		mlc = system.mes.loadMaterialLot(inlot,1,0)
		resseguuid = mlc.getPropertyValue('ResponseSegmentUUID')
		crs = system.mes.loadMESObject(resseguuid)
		moldSize = crs.getPropertyValue('moldSize')
		wid = float(moldSize[0:2])
		thk = float(moldSize[2:4])
		lbsperin = wid*thk
	except:
		pass
	if lbsperin > 0.0:
		logger.info('lbsperin: %f' % lbsperin)

	if KO.utils.lotCheckLog(lottags[0].value,'IngotSawTrim',0):

		endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
		startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value

		mlcast = system.mes.loadMaterialLot(inlot,1,0)
		mlsoak = system.mes.loadMaterialLot(inlot,-1,0)
		inQuantity = mlsoak.getLotInventory().getNetQuantity()


		logger.info('setup complete ' + str(inQuantity))
		try:
			ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
			logger.info('KO instantiated')
			logger.info('set materials')
			ko.materials['Material In'].quantity = inQuantity
			logger.info('createSegment')
			ko.createSegment()
			logger.info('setSegmentProperties')
			ko.setSegmentProperties()
			logger.info('setSegmentMaterials')
			ko.setSegmentMaterials()

			logger.info('pre begin' + str(startts))
			ko.seg = ko.seg.begin(startts)
			ko.updateSegmentMaterialProperties()
			ko.seg = ko.seg.update()

			ko.seg = ko.seg.update()
			logger.info('pre end' + str(endts))
			ko.seg.end(endts)
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				[system.date.now(),'complete'])
			logger.info('IngotSawTrim complete')
			return 1
 
		except:
			system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
				basetagpath + '/Interaction/reportErrorNotification'],
				['','Exception'])
			logger.info('IngotSawTrim Exception')
			pass
			return 0
	logger.info('lotCheckLog fail')
	return 0
	
def Part(equipPath,basetagpath,logger):
	
		optagpath = basetagpath + '/' + 'IngotSawTrim'
		lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
		inlot = str(lottags[0].value)
		logger.info('IngotSawTrim - operation start ' + str(inlot))
		if KO.utils.lotCheckLog(lottags[0].value,'IngotSawPart',0):
	
			endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
			startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value

			inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
	
			mlcast = system.mes.loadMaterialLot(inlot,1,0)
			mlsoak = system.mes.loadMaterialLot(inlot,-1,0)
			inQuantity = mlsoak.getLotInventory().getNetQuantity()
	
	
			#logger.info('setup complete')
			try:
				ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
	
				ko.createSegment()
				ko.setSegmentProperties()
				ko.setSegmentMaterials()
	
				ko.seg = ko.seg.begin(startts)
				ko.updateSegmentMaterialProperties()
				ko.seg = ko.seg.update()
	
				ko.seg = ko.seg.update()
				ko.seg.end(endts)
				system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
					basetagpath + '/Interaction/reportErrorNotification'],
					[system.date.now(),'complete'])
				logger.info('complete')
				return 1
	 
			except:
				system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
					basetagpath + '/Interaction/reportErrorNotification'],
					['','Exception'])
				logger.info('Exception')
				pass
				return 0
				
		return 0
		
def Scrap(equipPath,basetagpath,logger):
		
			logger.info('IngotSawScrap - operation start')
			optagpath = basetagpath + '/' + 'IngotSawScrap'
			lottags = system.tag.readBlocking([optagpath + '/Material In/Lot'])
			inlot = str(lottags[0].value)
			if KO.utils.lotCheckLog(lottags[0].value,'IngotSawScrap',0):
			
				endts = system.tag.readBlocking([basetagpath + '/Interaction/cycleEnd'])[0].value
				startts = system.tag.readBlocking([basetagpath + '/Interaction/cycleBegin'])[0].value

				inlot = system.tag.readBlocking([optagpath + '/Material In/Lot'])[0].value
		
				mlcast = system.mes.loadMaterialLot(inlot,1,0)
				mlsoak = system.mes.loadMaterialLot(inlot,-1,0)
				inQuantity = mlsoak.getLotInventory().getNetQuantity()
		
		
				logger.info('setup complete')
				try:
					ko = KO.baseOp.KaiserOperation(equipPath,basetagpath)
		
					ko.materials['Material In'].quantity = inQuantity
		
					ko.createSegment()
					ko.setSegmentProperties()
					ko.setSegmentMaterials()
		
					ko.seg = ko.seg.begin(startts)
					ko.updateSegmentMaterialProperties()
					ko.seg = ko.seg.update()
		
					ko.seg = ko.seg.update()
					ko.seg.end(endts)
					system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
						basetagpath + '/Interaction/reportErrorNotification'],
						[system.date.now(),'complete'])
					logger.info('complete')
					return 1
		 
				except:
					system.tag.writeBlocking([basetagpath + '/Interaction/cycleReported',
						basetagpath + '/Interaction/reportErrorNotification'],
						['','Exception'])
					logger.info('Exception')
					pass
					return 0
					
			return 0