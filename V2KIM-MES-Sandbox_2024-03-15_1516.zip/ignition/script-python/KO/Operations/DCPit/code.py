import system
def writeMaterialName(basepath,volatile):
	path = basepath + '/CAST/Material Out '
	for j in range(1,7):	#for all mold positions
		if volatile:
			#print path + "%d/MaterialName" %j,'Volatile Ingot'
			system.tag.write(path + "%d/MaterialName" %j,'Volatile Ingot')
		else:
			#print path + "%d/MaterialName" %j,'Ingot'
			system.tag.write(path + "%d/MaterialName" %j,'Ingot')
			
def check(basepath,i):	#(path to pit tags, station number)
	alloy   =   str(system.tag.read(basepath + '/CAST/castAlloy').value)
	length  = round(float(system.tag.read(basepath + '/CAST/Material Out 1/Length').value),1)
	targlen = round(system.tag.read(basepath + '/CAST/lengthScheduled').value,1)
	if (alloy[0] == '7' and alloy[2:] == '75' or alloy == 'K771' or alloy == 'k771') and length >= 235 or alloy == '7017':
			writeMaterialName(basepath,True)
	elif alloy[0] == 'K' or alloy[0] == 'k':
		if (alloy[1] == '7' and alloy[2] == '5') or (alloy[1] == '2' and alloy[2] == '1') or alloy[1:] == '791' or alloy[1:] == '777':
			#print 'Station %d'%i, alloy, length, 'volatile!'
			writeMaterialName(basepath,True)
		else:
			writeMaterialName(basepath,False)
	elif alloy == '2024':
		if length > targlen + 1:
			writeMaterialName(basepath,True)
		else:
			writeMaterialName(basepath,False)
	else:
		#print 'Station %d'%i, alloy, length
		writeMaterialName(basepath,False)
					
def doVolatileCheck(basepath):
		check(basepath,0)

