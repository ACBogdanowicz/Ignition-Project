def reset(basetagpath):
	results = system.tag.writeBlocking([
		basetagpath + '/Interaction/reportErrorNotification',
		basetagpath + '/Interaction/reportError',
		basetagpath + '/Interaction/cycleReported'],[
		'No Errors',
		0,
		0])
	if len(results) == 4: return 1
	else: return 0