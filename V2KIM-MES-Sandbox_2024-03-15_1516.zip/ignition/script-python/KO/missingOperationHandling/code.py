def layon(lot):
	import sys
	""" create a lot at layon iff it has been scalped. Otherwise fail in the usual manner."""
	logger = system.util.getLogger("myLogger")
	logger.info('top of missingOperationHandling layon')
	retstr = ''
	castAlloy = ''
	quantity = 0.0
	moldsize = ''
	length = 0.0
	width = 0.0
	thickness = 0.0
	try:
		cml = system.mes.loadMaterialLot(lot,1,0)
 		castAlloy = cml.getPropertyValue('castAlloy')
 		cm = system.mes.loadMaterialLot(lot,-1,0)
 		cmseq = cm.getLotSequence()
 		cmqty = float(cm.getLotInventory().getNetQuantity())
		try:
			moldsize = cml.getPropertyValue('moldSize')
			logger.info( moldsize )
		except:
			pass
 	except:
 		logger.info(str(sys.exc_info()))
		raise
	retstr = retstr + 'x\n'
	""" cmqty must be greater than 1 to indicate that it has a scalper scale weight """
	if cmqty > 1.0:
		for i in range(2,cmseq):
			try:
				retstr = retstr + str( (cmseq - 1)) + '\n'
				cmsaw = system.mes.loadMaterialLot(lot,(cmseq - 1),0)
				responseuuid = cmsaw.getPropertyValue('ResponseSegmentUUID')
				resp = system.mes.getMESObjectLink(responseuuid)
				logger.info( resp.name )
				if resp.name == 'SCALP':
					width = cmsaw.getPropertyValue('Width')
					length = cmsaw.getPropertyValue('Length')
					thickness = cmsaw.getPropertyValue('Thickness')
			except:
				logger.info(str(sys.exc_info()))
				raise

	return 1