import system
def run():
	filter = system.mes.lot.filter.createFilter()
	filter.setModeName('LOT')
	filter.setIncludeActiveLots(True)
	filter.setIncludeInactiveLots(True)
	filter.setMaxResults(50000)
	customPropertyValue = "MaterialLot.StatusCode=FP"

	list = filter.parseCustomPropertyValueFilter(customPropertyValue)
	filter.setCustomPropertyValueFilter(list)

	from java.util import Calendar
	beginCal = Calendar.getInstance()
	beginCal.add(Calendar.MONTH, -2)
	filter.setBeginDateTime(beginCal)
	endCal = Calendar.getInstance()
	filter.setEndDateTime(endCal)
	results = system.mes.getLotList(filter)
	print len(results)
	for link in results:
		print 'Found ' , link.getName()
	
def run2():
	import system

	filter = system.mes.lot.filter.createFilter()
	filter.setModeName('LOT')
	filter.setIncludeActiveLots(True)
	filter.setIncludeInactiveLots(False)
	filter.setMaxResults(1000)
	customPropertyValue = "MaterialLot.PartNumber=I21241658136AC,StatusCode!=OK"
	customPropertyValue2 = "MaterialLot.Length<64"
	
	list = filter.parseCustomPropertyValueFilter(customPropertyValue)
	filter.setCustomPropertyValueFilter(list)
	
	from java.util import Calendar
	beginCal = Calendar.getInstance()
	beginCal.add(Calendar.MONTH, -5)
	filter.setBeginDateTime(beginCal)
	endCal = Calendar.getInstance()
	filter.setEndDateTime(endCal)
	results = system.mes.getLotList(filter)
	print len(results)
	for link in results:
	 try:
		ml = system.mes.loadMaterialLot(link.getName(),1,False)
		allcustprop = ml.getAllCustomProperties()
		rslt = link.getName() + ','
		for cp in allcustprop:
			if cp.name == 'PartNumber':
				rslt = rslt + cp.value + ','
			if cp.name == 'Length':
				rslt = rslt + str(cp.value) + str(type(cp.value)) + ','
			if cp.name == 'StatusCode':
				rslt = rslt + cp.value
		print rslt
	 except:
		print link.getName()
		