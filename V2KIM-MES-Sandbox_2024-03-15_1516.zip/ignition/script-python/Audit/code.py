def showSoak(lotno):
	import system
	fc = system.mes.loadMaterialLot(lotno,-1,0)
	maxls = fc.getLotSequence()
	tgtls = maxls
	while tgtls > 1:
		tgtls = tgtls - 1
		print tgtls
		tgtlo = system.mes.loadMaterialLot(lotno,tgtls,0)
		rsuid = tgtlo.getPropertyValue('ResponseSegmentUUID')
		print rsuid
		rs = system.mes.getMESObjectLink(rsuid).getMESObject()
		print rs
		print rs.getPropertyValue('EndDateTime')
		if rs.name == 'autoSOAK':
			break
			
	print rs.getEquipmentLink().name
	for i in range(1,25):
		try:
			ml = rs.getMaterialLot('Material In %02d' % i)
			#print ml.name
			lml = system.mes.loadMaterialLot(ml.name,-1,0)
			rsuid = lml.getPropertyValue('ResponseSegmentUUID')
			#print rsuid
			try:
				irs = system.mes.getMESObjectLink(rsuid).getMESObject()
				#print irs
				print '%02d' %i,ml.name,'%12s' %irs.name,irs.getPropertyValue('EndDateTime')
			except:
				pass
		except:
			pass