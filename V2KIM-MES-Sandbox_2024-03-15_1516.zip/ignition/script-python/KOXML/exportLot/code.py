def do(lotnum, lotseq):
 ml = system.mes.loadMaterialLot(lotnum,lotseq,0)
 if lotseq < 0:
 	lotseq = ml.getLotSequence()
 responseSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
 others = KOXML.export2.OperationSegmentToFile(responseSegUUID,'[MES_Tags]Sandbox/SandboxLine/mes', lotnum)

 if len(others) > 0:
 	for item in others:
 		do(item[0],item[1])
 		
def doUntil(lotnum, lotseq,untilName):
 		 ml = system.mes.loadMaterialLot(lotnum,lotseq,0)
 		 if lotseq < 0:
 		 	lotseq = ml.getLotSequence()
 		 responseSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
 		 
 		 opseg = system.mes.getMESObjectLink(responseSegUUID).getMESObject()
 		 ops = opseg.getOperationsResponse()	
 		 opname = ops.name
 		 print opname
 		 if opname != untilName:
 		 	others = KOXML.export2.OperationSegmentToFile(responseSegUUID,'[MES_Tags]Sandbox/SandboxLine/mes', lotnum)
 		
 		 	if len(others) > 0:
 		 		for item in others:
 		 			doUntil(item[0],item[1],untilName)