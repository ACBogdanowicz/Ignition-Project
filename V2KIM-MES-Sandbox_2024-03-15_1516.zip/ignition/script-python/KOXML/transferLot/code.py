def do(lotnum, lotseq):
 import StringIO
 import os.path

 wstr = StringIO.StringIO()
 ml = system.mes.loadMaterialLot(lotnum,lotseq,0)
 responseSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
 opseg = system.mes.getMESObjectLink(responseSegUUID).getMESObject()
 
 opname = 'magically appear coil'
 wstr = StringIO.StringIO()
 filename = str(system.date.format(opseg.getPropertyValue('BeginDateTime'),'yyyy-MM-dd HH mm ss').replace(' ','_')) + '-' + str( opname ) + '_' + responseSegUUID + '.txt'
 wstr.write('#opname\n')
 wstr.write("%s\n" % opname)
 wstr.write('#basetagpath\n')
 wstr.write("%s\n" % '[MES_Tags]Sandbox/SandboxLine/mes')
 wstr.write("#uuid\n")
 wstr.write("nouuidforthisyet\n" )
 begdate = system.date.addMinutes( opseg.getPropertyValue('BeginDateTime'), -2)
 enddate = system.date.addMinutes( opseg.getPropertyValue('BeginDateTime'), -1)
 wstr.write("%s\n" % system.date.format(begdate,'yyyy-MM-dd HH:mm:ss'))
 wstr.write("#Interaction begin,end,name,eqpath\n")
 wstr.write("Interaction/cycleBegin,%s\n" % system.date.format(begdate,'yyyy-MM-dd HH:mm:ss'))
 wstr.write("Interaction/cycleEnd,%s\n" % system.date.format(enddate,'yyyy-MM-dd HH:mm:ss'))
 wstr.write("Interaction/cycleOperation,create purchased ingot\n")
 wstr.write("Interaction/equipmentPath,Kaiser\KAW\Admin\MES\n")
 wstr.write("#operation custom properties\n######0\n##Material Out##\n")
 wstr.write("Lot,%s\n" % ml.name)
 wstr.write("MaterialName,%s\n" % ml.getMaterialDefLink().name)
 wstr.write("Location,%s\n" % ml.getLocationLink().getMESObject().getEquipmentPath())
 
 print 'find material in properties'
 mat = opseg.getMaterialLot('Material In')
 matcp = mat.getAllCustomProperties()
 print matcp
 for cp in matcp:
 	# skip anything with two underscores and LastOp,
 	print cp.name
 	print cp.value
 	if ((cp.name.find('__') < 0) and cp.name[0:6] not in ['LastOp']):
 		wstr.write("%s,%s,%s\n" % (cp.name,cp.value,cp.getDataType()))
 
 filename = str(system.date.format(begdate,'yyyy-MM-dd HH mm ss')).replace(' ','_') + '-' + str( opname ) + '_' + responseSegUUID + '.txt'

 data = wstr.getvalue()
 print filename
 system.file.writeFile('C:\localignition\\%s' % filename,data,0)
 
 others = KOXML.export2.OperationSegmentToFile(responseSegUUID,'[MES_Tags]Sandbox/SandboxLine/mes', lotnum)
