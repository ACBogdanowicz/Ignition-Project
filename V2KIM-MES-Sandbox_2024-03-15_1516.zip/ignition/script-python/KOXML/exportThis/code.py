def do(lotnum, lotseq):
 ml = system.mes.loadMaterialLot(lotnum,lotseq,0)
 if lotseq < 0:
 	lotseq = ml.getLotSequence()
 responseSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
 others = KOXML.export2.OperationSegmentToFile(responseSegUUID,'[MES_Tags]Sandbox/SandboxLine/mes', lotnum)