def OperationSegmentToFile(opsegUUID,basetagpath,focalLot = None):
	trace = 1
	pretty = 0
	import StringIO
	import os.path
	others = []
	wstr = StringIO.StringIO()
	opseg = system.mes.getMESObjectLink(opsegUUID).getMESObject()
	segcp = opseg.getAllCustomProperties()
	if trace:
		print str(opseg.getPropertyValue('BeginDateTime'))
		print str(opseg.getPropertyValue('EndDateTime'))
		print segcp
	ops = opseg.getOperationsResponse()
	if trace:
		print ops.getUUID()
		print (ops)
		if 'pretty':
			print '----------pretty_dir'
			utils.pretty_dir(ops)
		
	opname = ops.name
	
	wstr.write('#opname\n')
	wstr.write("%s\n" % opname)
	wstr.write('#basetagpath\n')
	wstr.write("%s\n" % basetagpath )
	wstr.write("#uuid\n")
	wstr.write("%s\n" % opsegUUID )
	wstr.write("%s\n" % system.date.format(opseg.getPropertyValue('BeginDateTime'),'yyyy-MM-dd HH:mm:ss'))
	filename = str(system.date.format(opseg.getPropertyValue('BeginDateTime'),'yyyy-MM-dd HH mm ss').replace(' ','_')) + '-' + str( opname ) + '_' + opsegUUID + '.txt'
	if not system.file.fileExists("C:\localignition\\%s" % filename) :
		print 'no local copy'
	else:
		print 'run again'

	wstr.write('#Interaction begin,end,name,eqpath\n')
	wstr.write('Interaction/cycleBegin,%s\n' % system.date.format(opseg.getPropertyValue('BeginDateTime'),'yyyy-MM-dd HH:mm:ss'))
	wstr.write('Interaction/cycleEnd,%s\n' % system.date.format(opseg.getPropertyValue('EndDateTime'),'yyyy-MM-dd HH:mm:ss'))
	wstr.write('Interaction/cycleOperation,%s\n' % opseg.getOperationsResponse().name)
	wstr.write('Interaction/equipmentPath,%s\n' % opseg.getEquipment().equipmentPath)
			
	wstr.write('#operation custom properties\n')
	for cp in segcp:
		print cp
		wstr.write("%s,%s\n" % (cp.name,cp.value))
	
	opd = opseg.getOperationsDefinition()
	if trace:
		print 'opd'
		print opd.getUUID()
		print (opd)
		#utils.pretty_dir(opd)
	if trace:
		print 'ops'
		print ops.getUUID()
		print (ops)
		if pretty:
			utils.pretty_dir(ops)
		
	#segments = ops.getAvailableSegments()
	segments = ops.getResponseSegments()
	if trace:
		print '------------ segments -----------------'
		print str(segments)
		print '------------ segments -----------------'
	for segl in segments:
		if trace: print segl
		seg = segl.getMESObject()
		segmatcnt = seg.getComplexPropertyCount('ResponseMaterial')
		for i in range(segmatcnt):
		 wstr.write('######%d\n' % i)
		 segmat = seg.getComplexProperty('ResponseMaterial',i)
		 if pretty: utils.pretty_dir(segmat)
		 wstr.write('##%s##\n' % segmat.getBaseName() )
		 #wstr.write('%s\n' % segmat.getUse())
		 try:
			if trace:
				print i
				print segmat.name
				print str(segmat.getUse())
				print segmat.getAllCustomProperties()
			try:
				mat = opseg.getMaterialLot(segmat.name)
				#print 'inventory'
				#print mat.getLotInventory().getNetQuantity()
				#if str(segmat.getUse()) == 'Out':
				#	wstr.write('Quantity,%s\n' % mat.getLotInventory().getNetQuantity())
				#print segmat.name
				#print mat
				wstr.write('Lot,%s\n' % mat.name )
				print segmat.getUse()
				if segmat.getUse() == 'Out':
					others.append((mat.name,mat.getLotSequence()))
				skip="""
				if segmat.getUse() == 'In':
					if focalLot != None:
						if focalLot != mat.name:
							print mat.name
							others.append((mat.name,mat.getLotSequence()))
				"""
			except:
				wstr.write('Lot,\n')
				
			#matinv = mat.getMaterialRef().getLotInventory()
			#print matrespdef.getQuantitySource()
			#if matrespdef.getQuantitySource() == 'Manual':
			#	wstr.write("system.tag.writeBlocking([ basetagpath + '\\' + opname + '\\' + %s + '\\' + '%s' ],['%s'])\n" % (segmat.name,'Quantity',matdef.getQuantity()))
			try:
				matdef = mat.getMaterialDefLink().getMESObject()
				wstr.write('MaterialName,%s\n' % matdef.name )
			except:
				wstr.write('MaterialName,\n')
			if trace: print mat
			
			matcp = mat.getAllCustomProperties()
			print matcp
			for cp in matcp:
				# skip anything with two underscores and LastOp,
				print cp.name
				print cp.value
				if ((cp.name.find('__') < 0) and cp.name[0:6] not in ['LastOp']):
					if trace:
						print cp.name
						print cp.value
					wstr.write("%s,%s,%s\n" % (cp.name,cp.value.cp.type))
		 except:
		 	wstr.write('#error %s\n' % i)
				
	data = wstr.getvalue()
	print filename
	system.file.writeFile('C:\localignition\\%s' % filename,data,0)
	return others
	if trace: print wstr.getvalue()