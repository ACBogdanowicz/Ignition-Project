lot = '482331B6-1'
ml = system.mes.loadMaterialLot(lot,-1,0)
lseq = ml.getLotSequence()
print lseq
responseSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
opseg = system.mes.getMESObjectLink(responseSegUUID).getMESObject()
print opseg.name
print system.date.format(opseg.getPropertyValue('BeginDateTime'),'yyyy-MM-DD HH:mm:ss')
print system.date.format(opseg.getPropertyValue('EndDateTime'),'yyyy-MM-DD HH:mm:ss')
matin = opseg.getMaterialLot('Material In')
pmatin = matin.getAllCustomProperties()
for each in pmatin:
	print 'in ',each.name,each.value,each.dataType.name
matout = opseg.getMaterialLot('Material Out')
pmatout = matout.getAllCustomProperties()

pml = system.mes.loadMaterialLot(lot,lseq -1,0)
popseg = system.mes.getMESObjectLink(pml.getPropertyValue('ResponseSegmentUUID')).getMESObject()
pmatout = popseg.getMaterialLot('Material Out')
for each in pmatout.getAllCustomProperties():
	print 'out',each.name, each.value, each.dataType.name