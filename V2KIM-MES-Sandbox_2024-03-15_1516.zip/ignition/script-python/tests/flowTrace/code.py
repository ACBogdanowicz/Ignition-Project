def find(resegs,uuid):
	dataset = system.mes.getLotTraceByLotUUID(uuid,'')
	return resegs,uuid

def do(lotnumber):
	resegs = []
	ml = system.mes.loadMaterialLot(lotnumber,1,True)
	uuid = ml.getPropertyValue('UUID')
	resegs,uuid = find(resegs,uuid)