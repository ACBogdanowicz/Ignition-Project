def doAllWagons():
	wagclass = system.mes.getMESObjectLinkByName('EquipmentClass','Wagons').getMESObject()
	wagons = wagclass.getChildCollection()
	cnt = 1
	for wag in wagons:
		wobj = system.mes.loadMESObject(wag)
		print str('%03d' % cnt),str(wobj.name)
		tests.wagonaging.doSingleWagon(wobj.name)
		cnt = cnt + 1

def doSingleWagon(wagonId):
	import RossData

	seg = system.mes.createSegment('moveMaterial','Kaiser\KAW\Admin\Handling',True)
	nextlots = seg.getAvailableMaterialLots('Material In',wagonId)
	if len(nextlots) > 0:
		mestoplot = nextlots[0]
		parentlot = ''
		extension = ''
		if str(mestoplot.name).find('-') > 0:
			parentlot,extension = str(mestoplot.name).split('-')
			print parentlot, '_', extension
		else:
			parentlot = mestoplot.name
			print parentlot
	
	
		respuuid = mestoplot.getMESObject().getPropertyValue('ResponseSegmentUUID')
		print respuuid
		resp = system.mes.loadMESObject(respuuid)
		lastdate = resp.getPropertyValue('EndDateTime')
		lasttrace = resp.name
		age = system.date.hoursBetween(lastdate,system.date.now())
		print lasttrace
		print age
		
		locPath = None
		lotinfo = RossData.getRossLotInfoBoomi(parentlot)
		stage = lotinfo['LOT']['HISTORY'][0]['STAGE']
		print 'lastROSS ', stage

		if locPath == None and stage[0:3] in ['HHT']:	
			if age > 100:
				locPath = 'Kaiser\KAW\Plate Flow\Plate Flow Inventory\Plate Inventory'
				print 'over 100 hours old move to plate inventory'
			else:
				locPath = None
		if locPath == None and stage[0:4] in ['STR1','STR7']:
			print 'lot has been stretched move to plate inventory'
			locPath = 'Kaiser\KAW\Plate Flow\Plate Flow Inventory\SMHCS Plate Inventory'
		if locPath == None and stage[0:4] in ['BAIR','BINR']:
			print 'lot has been through batch move to blue room inventory'
			locPath = 'Kaiser\KAW\Plate Flow\Plate Flow Inventory\Blue Room Inventory'
		if locPath == None and  stage[0:2] == 'HR':
			print 'lot has not been touched since rolling. Leave as is.'
			locPath = None
		if locPath == None and stage[0:3] == 'TWD':
			locPath = 'Kaiser\KAW\Shipping\Shipping Inventory\Trentwood Staging Area'
		if locPath == None and stage in ['LAB','REPORT']:
			locPath = 'Kaiser\KAW\Shipping\Shipping Inventory\Packed Plate Inventory'

		if locPath != None:
			cnt = 0
			parentFound = 0
			done = 0
			state = 'ok'
			removedict = {}
			for nl in nextlots:
				print nl.name
				name = nl.name
				if name.find('-') > 0:
					baselot = name.split('-')[0]
				else:
					baselot = name
				if ((not done) and (not parentFound)):
					state = 'ok'
				if ((not done) and (not parentFound) and (baselot == parentlot)):
					parentFound = 1
				if (parentFound and (baselot != parentlot)):
					state = 'no'
				print state
				removedict[name] = state
				if state == 'ok':
					obj = nl.getMESObject()
					seg = system.mes.createSegment('UnloadWagonPlateToInventory','Kaiser\KAW\Admin\Handling', True)
					seg.setMaterial('Material In', obj.name)
					seg.setMaterial('Material Out','Plate',locPath,obj.name,obj.getLotInventory().getNetQuantity())
					seg.execute()
					# below moves the lot to the location without operation.
					#qObj = system.mes.getMESObjectLinkByEquipmentPath(locPath).getMESObject()
					#bj.setPropertyValue('LotLocationRefUUID',eqObj.getUUID())
					system.mes.saveMESObject(obj)
				
	