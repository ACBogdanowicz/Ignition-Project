class TraceOperation:
  def __init__(self,pydsrow,databaseName):
  	self.pydsrow = pydsrow
  	self.OperationRefUUID = pydsrow[0]
  	self.beginDateTime = pydsrow[1]
  	self.endDateTime = pydsrow[2]
  	self.eqName = pydsrow[3]
  	self.segName = pydsrow[4]
  	self.MESResponseSegmentUUID = pydsrow[5]
  	self.MESOperationResponseUUID = pydsrow[6]
  	self.databaseName = databaseName
  	self.responseSegment = system.mes.loadMESObject(self.MESResponseSegmentUUID)

  	self.operationSegment = system.mes.loadMESObject(self.MESOperationResponseUUID)
  	self.materials = []
  	self.baselots = []
  	self.getMaterials()
  	self.materialColumnNames = ['name','use','baselot','lot','material','quantity','status','lotUUID']
  	
  def getBaselots(self):
  	return self.baselots
  	
  def opSegProperties(self):
  	self.opseg = system.mes.getMESObjectLink(self.MESOperationResponseUUID).getMESObject()
  	return self.opseg.getCustomPropertiesFull()
  	
  def respSegProperties(self):
  	self.respseg = system.mes.getMESObjectLink(self.MESResponseSegmentUUID).getMESObject()
  	return self.respseg.getCustomPropertiesFull()
  
  def getMaterials(self):
	matcnt = self.responseSegment.getComplexPropertyCount('ResponseMaterial')
  	for j in range(0,matcnt):
  	 try:
  		jname = self.responseSegment.getComplexProperty('ResponseMaterial',j).name
  		juse = self.responseSegment.getComplexProperty('ResponseMaterial',j).use
  		item = []
  		item.append(str(jname))
  		item.append(str(juse))
  		ml = self.responseSegment.getMaterialLot(jname)
  		item.append(str(ml.name)[0:8])
  		if str(ml.name)[0:8] not in self.baselots:
  			if ml.name[0:6].isnumeric():
  				self.baselots.insert(0,[str(ml.name)[0:8],ml.name,ml.lotSequence,str(juse)])
  		item.append(str(ml.name))
  		item.append(ml.lotSequence)
  		item.append(ml.getMaterialDefLink().getMESObject().name)
  		if juse == u'Out':
  			item.append(ml.getLotInventory().getOutQuantity())
  		else:
  			item.append(ml.getLotInventory().getInQuantity())
  		#item.append(ml.getLotInventory())
  		item.append(ml.getLotAvailabilityStatus())
  		item.append(ml.getUUID())
  		self.materials.append(item)
  	 except:
  	 	pass

  def getBaseLots(self):
  	return self.baselots

class PeriodReport:
  def __init__(self,eqName,startDate,endDate,databaseName):
  	self.baselots = []
  	self.eqName = eqName
  	self.startDate = startDate
  	self.endDate = endDate
  	self.databaseName = databaseName
  	print self.eqName,self.startDate,self.endDate,self.databaseName
	operationpyds = Reporting.TrackingQueries.getForEquipmentPeriod ( eqName,startDate,endDate, databaseName )
	self.traceops = []
	for row in operationpyds:
		print row
		top = TraceOperation(row,databaseName)
		for l in top.getBaselots():
			if l not in self.baselots:
				self.baselots.append(l)
		self.traceops.append(top)
		
  def getOperations(self):
  	for op in self.traceops:
  		op.getBaseLots()
  def getBaselots(self):
  	return self.baselots
  		
  def PopulateTableWithOperations(tableObj):
	
  	tableObj.data = system.dataset.clearDataset(tableObj.data)
  	cnt = 0
 
  	dataset = tableObj.data
  	headers = ['Operation','Lots']
  	data = []
  	tableObj.data = system.dataset.toDataSet(headers,data)
  	cnt = 0
  							
  	for i in range(0,len( preport.traceops )):
  		tableObj.data = system.dataset.addRow(tableObj.data,[preport.traceops[i].responseSegment.name,'oreo'])
  		cnt = cnt + 1
  		i = i + 1
  	return cnt

def tests():
	trace = 1
	import Reporting

	roset = Reporting.ReportObjects.PeriodReport('DC0','2023-07-01 00:07:00','2023-07-26 00:07:00', 'popcorn')
	print roset
	print 'responseSegment','operationResponse'
	for top in roset.traceops:
		print top.MESResponseSegmentUUID,top.MESOperationResponseUUID
		lots = top.getLots()
		for ml in lots:
			for i in range(0,16):
		  		print i,ml[i]

	print 'end'
	
def junk():
 import Reporting
 import system
 import utils


 roset = Reporting.ReportObjects.PeriodReport('DC0','2023-07-01 00:07:00','2023-07-26 00:07:00', 'popcorn')
 print roset
 print 'responseSegment','operationResponse'
 for i in range(0,len(roset.traceops)):
	print roset.traceops[i].MESResponseSegmentUUID,roset.traceops[i].MESOperationResponseUUID

	reseg = system.mes.loadMESObject(roset.traceops[i].MESResponseSegmentUUID)
	opseg = system.mes.loadMESObject(roset.traceops[i].MESOperationResponseUUID)
	print 'reseg ',reseg
	print reseg.getAllCustomProperties()
	#utils.pretty_dir(reseg)
	mo = reseg.getMaterialLot('Material Out 1')
	print mo
	grog = reseg.getComplexPropertyCollection('Material')
	print grog
	print reseg.getComplexPropertyCount('Material')
	print reseg.getComplexPropertyByKind('Material')
	matcnt = reseg.getComplexPropertyByKind('Material')
	print matcnt
	
def fieldtest():
	 import Reporting
	 import datetime
	 import utils
	 bd = datetime.datetime(2022,1,1,0,0,0)
	 ed = datetime.datetime(2024,1,1,0,0,0)
	 def sortByDate(val):
	 	return val[5]
	 roset = Reporting.ReportObjects.PeriodReport('DC0-Pit','2023-07-23 07:00:00','2023-08-25 09:00:00', 'popcorn')
	 lotlist = roset.getBaselots()
	 ordered = []
	 for i in range(0,len(lotlist)):
		print '------------------ %s -----------' % lotlist[i]
		ordered = []
		filter = system.mes.lot.filter.createFilter()
		filter.setIncludeInactiveLots(True)
		filter.setBeginDateTime(bd)
		filter.setEndDateTime(ed)
		filter.setLotNameFilter('%s*' % lotlist[i])
		mllist = system.mes.getLotList(filter)
		for item in mllist:
			ml = item.getMESObject()
			try:
				ll = system.mes.loadMaterialLot(ml.name,-1,0)
				cls = ll.getLotSequence()
			except:
				cls = 0
			try:
				bl,el = (ml.name).split('-')
			except:
				bl = ml.name
				el = ''
			try:
				jb = rseg.getPropertyValue('Job')
			except:
				jb = ''
			rseg = system.mes.loadMESObject(ml.getPropertyValue('ResponseSegmentUUID'))
			#print ('%15s %5s %2d %5s %25s %30s %s' % (bl,el,cls,ml.getLotSequence(),rseg.name,rseg.getEndDateTime(),jb))
			ordered.append((bl,el,cls,ml.getLotSequence(),rseg.name,rseg.getEndDateTime(),rseg.getUUID(),jb))
					
			ordered.sort(key=sortByDate,reverse=1)
			for ea in ordered:
				print ('%15s %5s %2d %5s %25s %30s %s %s' % ea)
			
		ordered.sort(key=sortByDate,reverse=1)
		for ea in ordered:
			print ('%15s %5s %2d %5s %25s %30s %s %s' % ea)