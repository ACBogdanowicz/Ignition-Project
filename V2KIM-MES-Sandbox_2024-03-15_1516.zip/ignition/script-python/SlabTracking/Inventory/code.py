def findBaseLotResults(baselot):
	from java.util import Calendar
	
	mlist = []
	filter = system.mes.inventory.filter.createFilter()
	filter.setIncludeCompleteLots(True)
	filter.setEquipmentPath('Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking')
	beginCal = Calendar.getInstance()
	beginCal.add(Calendar.DAY_OF_MONTH, -30)
	filter.setBeginDateTime(beginCal)
	endCal = Calendar.getInstance()
	filter.setEndDateTime(endCal)
	print beginCal.getTime()
	print endCal.getTime()
	results = system.mes.getInventory(filter)
	print results.rowCount
	for rowIndex in range(results.getRowCount()):
		#print str(rowIndex)
		#print str(results.getValueAt(rowIndex, 0))
		mo = system.mes.loadMESObject(results.getValueAt(rowIndex, 0))
		#print mo.name
		if str(mo.name).find(baselot) > -1:
			mlist.append(mo)
			print mo.name

	system.mes.getInventory
	return mlist
	
def findBaseLotResults2(baselot):
	from java.util import Calendar
 
	eqfilter = system.mes.lot.filter.createFilter()
	eqfilter.setLotEquipmentNameFilter('Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking')
 	mlist = []
	filter = system.mes.lot.filter.createFilter()
	#added

	#return
	filter.setModeName('LOT')
	filter.setIncludeInactiveLots(True)
	filter.setLotEquipmentNameFilter('Slab Tracking')
	beginCal = Calendar.getInstance()
	beginCal.add(Calendar.DAY_OF_MONTH, -30)
	filter.setBeginDateTime(beginCal)
	endCal = Calendar.getInstance()
	filter.setEndDateTime(endCal)
	results = system.mes.getLotList(filter)
	#print len(results)
	for link in results:
	    #print link.getName()
	    if str(link.getName()).find(baselot) > -1:
	    	mlist.append(mo)
	    	print mo.name
	return mlist
	
def findBaseLotResults3(baselot):
	# diversion lots do not have a parent lot, however, they are reported by the parent lot.
	if len(baselot) > 8:
		baselot = baselot[0:8]
	mlist = []
	seg = system.mes.createSegment('slabInventory','Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking',True)
	lotlist = seg.getAvailableMaterialLots('Material In','Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking')
	appendlot = None
	lastsuffix = 1000
	#print lotlist
	for link in lotlist:
		#print link.getName()
		if link.getName() == baselot:
			#print "is baselot"
			appendlot = link.getMESObject()
		else:
			if str(link.getName()).find(baselot) > -1:
				fullname = link.getName()
				suffixstr = fullname[len(baselot)+1:]
				#print suffixstr
				if len(suffixstr) > 0:
					suffix = int(suffixstr)
					if suffix == 1:
						mlist.insert(0,link.getMESObject())
					else:
						mlist.append(link.getMESObject())
				
	if appendlot != None:
		mlist.append(appendlot)

	return mlist
	
def findBaseLotResults4(baselot):
		mlist = []
		if len(baselot) > 8:
			baselot = baselot[0:8]
		print baselot
		seg = system.mes.createSegment('slabInventory','Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking',True)
		lotlist = seg.getAvailableMaterialLots('Material In','Kaiser\KAW\Hot Rolling\Hot Rolling Locations\Slab Tracking')
		appendlot = None
		lastsuffix = 1000
		#print lotlist
		for link in lotlist:
			#print link.getName()
			if link.getName() == baselot:
				#print "is baselot"
				appendlot = link.getMESObject()
			else:
				if str(link.getName()).find(baselot) > -1:
					fullname = link.getName()
					suffixstr = fullname[len(baselot)+1:]
					#print suffixstr
					if len(suffixstr) > 0:
						suffix = int(suffixstr)
						if suffix == 1:
							mlist.insert(0,link.getMESObject())
						else:
							mlist.append(link.getMESObject())
					
		if appendlot != None:
			mlist.append(appendlot)
	
		return mlist
		
def show(baselot):
	result = SlabTracking.Inventory.findBaseLotResults3(baselot)
	print result
	print len(result)
	firstdate = None
	first = 1
	for ml in result:
		print ml.name
		print ml.getLotSequence()
		print ml.getLotInventory().getNetQuantity()
		locObj = ml.getLocationLink().getMESObject()
		print locObj.name
		print ml.getPropertyValue('LotAvailabilityStatus')
		print ml.getPropertyValue('LotStatus')
		respSegUUID = ml.getPropertyValue('ResponseSegmentUUID')
		print respSegUUID
		respObj = system.mes.getMESObjectLink(respSegUUID).getMESObject()
		print respObj.name
		if first:
			firstdate = respObj.getPropertyValue('EndDateTime')
			first = 0
		print respObj.getPropertyValue('EndDateTime')
		if not first:
			print system.date.secondsBetween(firstdate,respObj.getPropertyValue('EndDateTime'))