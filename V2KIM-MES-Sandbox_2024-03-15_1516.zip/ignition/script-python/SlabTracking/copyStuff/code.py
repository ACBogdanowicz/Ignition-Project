def do(fromlot,fromseq,tolot,toseq):

	nml = system.mes.loadMaterialLot(tolot,toseq,0)
	#print (nml.getLotSequence())
	ml = system.mes.loadMaterialLot(fromlot,fromseq,0)
	custprops = ml.getAllCustomProperties()
	for cp in custprops:
		#print ( cp )
		if cp.name not in ['EquipmentName','LastOp']:
			#print ('dt', cp.getIgnitionDataType() )
			try:
				nml.addCustomProperty(cp.name,str(cp.getIgnitionDataType()),cp.getDescription(),cp.getUnits(),1,1)
				nml.setPropertyValue(cp.name,cp.value)
			except:
				#print 'exception'
				#print cp.name
				raise
					
	system.mes.saveMESObject(nml)