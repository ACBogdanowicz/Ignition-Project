def fetchLotStringResult(lotno):
	url = 'http://frpbmp.kaiseraluminum.com/ws/rest/erp/lot/?Lot=' + lotno
	lotqrystring = system.net.httpGet(url)
	return lotqrystring
	
def fetchLot(lotno):
	import system

	url = 'http://frpbmp.kaiseraluminum.com/ws/rest/erp/lot/?Lot=' + lotno
	print url
	lotqrydict = eval(system.net.httpGet(url))
	print 'lotqrydict'
	print lotqrydict.keys()
	return lotqrydict
	
def fetchJob(jobno,stage):
	import system

	url = 'http://frpbmp.kaiseraluminum.com/ws/rest/erp/job/?Job=' + jobno + '&Stage=' + stage
	print url
	lotqrydict = eval(system.net.httpGet(url))
	print 'lotqrydict'
	print lotqrydict.keys()
	return lotqrydict
